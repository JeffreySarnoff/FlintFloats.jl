/*
    Copyright (C) 2010 Fredrik Johansson

    2x2 mul code taken from MPFR 2.3.0
    (Copyright (C) 1991-2007 Free Software Foundation, Inc.)

    invert_pi1, udiv_qrnnd_preinv and udiv_qr_3by2 adapted from GMP's
    gmp-impl.h:
    Copyright 1991-2018, 2021, 2022 Free Software Foundation, Inc.

    This file is part of FLINT.

    FLINT is free software: you can redistribute it and/or modify it under
    the terms of the GNU Lesser General Public License (LGPL) as published
    by the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.  See <https://www.gnu.org/licenses/>.
*/

#ifndef MPN_EXTRAS_H
#define MPN_EXTRAS_H

#ifdef MPN_EXTRAS_INLINES_C
#define MPN_EXTRAS_INLINE
#else
#define MPN_EXTRAS_INLINE static inline
#endif

#include <gmp.h>
#include "longlong.h"
#include "ulong_extras.h"
#include "flint-mparam.h"

#ifdef __cplusplus
extern "C" {
#endif

/* mpn macros ****************************************************************/

FLINT_FORCE_INLINE
void flint_mpn_zero(mp_ptr xp, mp_size_t n)
{
    mp_size_t ix;
    for (ix = 0; ix < n; ix++)
        xp[ix] = UWORD(0);
}

FLINT_FORCE_INLINE
void flint_mpn_copyi(mp_ptr xp, mp_srcptr yp, mp_size_t n)
{
    mp_size_t ix;
    for (ix = 0; ix < n; ix++)
        xp[ix] = yp[ix];
}

FLINT_FORCE_INLINE
void flint_mpn_copyd(mp_ptr xp, mp_srcptr yp, mp_size_t n)
{
    mp_size_t ix;
    for (ix = n - 1; ix >= 0; ix--)
        xp[ix] = yp[ix];
}

/* Copying and zeroing for short operands. The plain loops above are
   turned into calls to memcpy / memset by the compiler, which cost more
   than the operation itself for a few limbs. */
FLINT_FORCE_INLINE
void _flint_mpn_copy_small(mp_ptr d, mp_srcptr s, mp_size_t n)
{
    switch (n)
    {
        case 8: d[7] = s[7]; /* fallthrough */
        case 7: d[6] = s[6]; /* fallthrough */
        case 6: d[5] = s[5]; /* fallthrough */
        case 5: d[4] = s[4]; /* fallthrough */
        case 4: d[3] = s[3]; /* fallthrough */
        case 3: d[2] = s[2]; /* fallthrough */
        case 2: d[1] = s[1]; /* fallthrough */
        case 1: d[0] = s[0]; /* fallthrough */
        case 0: break;
        default: flint_mpn_copyi(d, s, n);
    }
}

FLINT_FORCE_INLINE
void _flint_mpn_zero_small(mp_ptr d, mp_size_t n)
{
    switch (n)
    {
        case 8: d[7] = 0; /* fallthrough */
        case 7: d[6] = 0; /* fallthrough */
        case 6: d[5] = 0; /* fallthrough */
        case 5: d[4] = 0; /* fallthrough */
        case 4: d[3] = 0; /* fallthrough */
        case 3: d[2] = 0; /* fallthrough */
        case 2: d[1] = 0; /* fallthrough */
        case 1: d[0] = 0; /* fallthrough */
        case 0: break;
        default: flint_mpn_zero(d, n);
    }
}

FLINT_FORCE_INLINE
void flint_mpn_store(mp_ptr xp, mp_size_t n, mp_limb_t y)
{
    mp_size_t ix;
    for (ix = 0; ix < n; ix++)
        xp[ix] = y;
}

MPN_EXTRAS_INLINE
int flint_mpn_zero_p(mp_srcptr x, mp_size_t xsize)
{
    slong i;
    for (i = 0; i < xsize; i++)
    {
        if (x[i])
            return 0;
    }
    return 1;
}

FLINT_FORCE_INLINE
int flint_mpn_equal_p(mp_srcptr x, mp_srcptr y, mp_size_t xsize)
{
    slong i;
    for (i = 0; i < xsize; i++)
    {
        if (x[i] != y[i])
            return 0;
    }
    return 1;
}

FLINT_FORCE_INLINE void
flint_mpn_negmod_n(mp_ptr res, mp_srcptr x, mp_srcptr m, mp_size_t n)
{
    if (flint_mpn_zero_p(x, n))
        flint_mpn_zero(res, n);
    else
        mpn_sub_n(res, m, x, n);
}

FLINT_FORCE_INLINE void
flint_mpn_addmod_n(mp_ptr res, mp_srcptr x, mp_srcptr y, mp_srcptr m, mp_size_t n)
{
    mp_limb_t cy;
    cy = mpn_add_n(res, x, y, n);
    if (cy || mpn_cmp(res, m, n) >= 0)
        mpn_sub_n(res, res, m, n);
}

FLINT_FORCE_INLINE void
flint_mpn_submod_n(mp_ptr res, mp_srcptr x, mp_srcptr y, mp_srcptr m, mp_size_t n)
{
    int cmp = (mpn_cmp(x, y, n) < 0);
    mpn_sub_n(res, x, y, n);
    if (cmp)
        mpn_add_n(res, res, m, n);
}

/* assumes yn <= n and y < m */
FLINT_FORCE_INLINE void
flint_mpn_addmod_n_m(mp_ptr res, mp_srcptr x, mp_srcptr y, mp_size_t yn, mp_srcptr m, mp_size_t n)
{
    mp_limb_t cy;
    cy = mpn_add(res, x, n, y, yn);
    if (cy || mpn_cmp(res, m, n) >= 0)
        mpn_sub_n(res, res, m, n);
}

/* assumes yn <= n and y < m */
FLINT_FORCE_INLINE void
flint_mpn_submod_n_m(mp_ptr res, mp_srcptr x, mp_srcptr y, mp_size_t yn, mp_srcptr m, mp_size_t n)
{
    int cmp = (flint_mpn_zero_p(x + yn, n - yn) && mpn_cmp(x, y, yn) < 0);
    mpn_sub(res, x, n, y, yn);
    if (cmp)
        mpn_add_n(res, res, m, n);
}

FLINT_FORCE_INLINE void
flint_mpn_negmod_2(mp_ptr res, mp_srcptr x, mp_srcptr m)
{
    if (x[0] == 0 && x[1] == 0)
        res[1] = res[0] = 0;
    else
        sub_ddmmss(res[1], res[0], m[1], m[0], x[1], x[0]);
}

FLINT_FORCE_INLINE void
flint_mpn_addmod_2(mp_ptr res, mp_srcptr x, mp_srcptr y, mp_srcptr m)
{
    mp_limb_t cy;
    mp_limb_t m1 = m[1], m0 = m[0];
    add_sssaaaaaa(cy, res[1], res[0], 0, x[1], x[0], 0, y[1], y[0]);
    if (cy || (res[1] > m1 || (res[1] == m1 && res[0] >= m0)))
        sub_ddmmss(res[1], res[0], res[1], res[0], m1, m0);
}

/* assumes msb of m is zero */
FLINT_FORCE_INLINE void
_flint_mpn_addmod_2(mp_ptr res, mp_srcptr x, mp_srcptr y, mp_srcptr m)
{
    mp_limb_t m1 = m[1], m0 = m[0];
    add_ssaaaa(res[1], res[0], x[1], x[0], y[1], y[0]);
    if (res[1] > m1 || (res[1] == m1 && res[0] >= m0))
        sub_ddmmss(res[1], res[0], res[1], res[0], m1, m0);
}

FLINT_FORCE_INLINE void
flint_mpn_submod_2(mp_ptr res, mp_srcptr x, mp_srcptr y, mp_srcptr m)
{
    int cmp;
    mp_limb_t m1 = m[1], m0 = m[0];
    mp_limb_t x1 = x[1], x0 = x[0];
    mp_limb_t y1 = y[1], y0 = y[0];
    cmp = (x1 < y1) || (x1 == y1 && x0 < y0);
    sub_ddmmss(res[1], res[0], x1, x0, y1, y0);
    if (cmp)
        add_ssaaaa(res[1], res[0], res[1], res[0], m1, m0);
}

FLINT_FORCE_INLINE int
flint_mpn_signed_sub_n(mp_ptr res, mp_srcptr x, mp_srcptr y, mp_size_t n)
{
    if (mpn_cmp(x, y, n) >= 0)
    {
        mpn_sub_n(res, x, y, n);
        return 0;
    }
    else
    {
        mpn_sub_n(res, y, x, n);
        return 1;
    }
}

/* add without carry in or carry out */
#define NN_ADD_2(r, u, v) add_ssaaaa((r)[1], (r)[0], (u)[1], (u)[0], (v)[1], (v)[0])
#define NN_ADD_3(r, u, v) add_sssaaaaaa((r)[2], (r)[1], (r)[0], (u)[2], (u)[1], (u)[0], (v)[2], (v)[1], (v)[0])
#define NN_ADD_4(r, u, v) add_ssssaaaaaaaa((r)[3], (r)[2], (r)[1], (r)[0], (u)[3], (u)[2], (u)[1], (u)[0], (v)[3], (v)[2], (v)[1], (v)[0])
#define NN_ADD_5(r, u, v) add_sssssaaaaaaaaaa((r)[4], (r)[3], (r)[2], (r)[1], (r)[0], (u)[4], (u)[3], (u)[2], (u)[1], (u)[0], (v)[4], (v)[3], (v)[2], (v)[1], (v)[0])
#define NN_ADD_6(r, u, v) add_ssssssaaaaaaaaaaaa((r)[5], (r)[4], (r)[3], (r)[2], (r)[1], (r)[0], (u)[5], (u)[4], (u)[3], (u)[2], (u)[1], (u)[0], (v)[5], (v)[4], (v)[3], (v)[2], (v)[1], (v)[0])
#define NN_ADD_7(r, u, v) add_sssssssaaaaaaaaaaaaaa((r)[6], (r)[5], (r)[4], (r)[3], (r)[2], (r)[1], (r)[0], (u)[6], (u)[5], (u)[4], (u)[3], (u)[2], (u)[1], (u)[0], (v)[6], (v)[5], (v)[4], (v)[3], (v)[2], (v)[1], (v)[0])
#define NN_ADD_8(r, u, v) add_ssssssssaaaaaaaaaaaaaaaa((r)[7], (r)[6], (r)[5], (r)[4], (r)[3], (r)[2], (r)[1], (r)[0], (u)[7], (u)[6], (u)[5], (u)[4], (u)[3], (u)[2], (u)[1], (u)[0], (v)[7], (v)[6], (v)[5], (v)[4], (v)[3], (v)[2], (v)[1], (v)[0])

#define NN_SUB_2(r, u, v) sub_ddmmss((r)[1], (r)[0], (u)[1], (u)[0], (v)[1], (v)[0])
#define NN_SUB_3(r, u, v) sub_dddmmmsss((r)[2], (r)[1], (r)[0], (u)[2], (u)[1], (u)[0], (v)[2], (v)[1], (v)[0])
#define NN_SUB_4(r, u, v) sub_ddddmmmmssss((r)[3], (r)[2], (r)[1], (r)[0], (u)[3], (u)[2], (u)[1], (u)[0], (v)[3], (v)[2], (v)[1], (v)[0])
#define NN_SUB_5(r, u, v) sub_dddddmmmmmsssss((r)[4], (r)[3], (r)[2], (r)[1], (r)[0], (u)[4], (u)[3], (u)[2], (u)[1], (u)[0], (v)[4], (v)[3], (v)[2], (v)[1], (v)[0])
#define NN_SUB_6(r, u, v) sub_ddddddmmmmmmssssss((r)[5], (r)[4], (r)[3], (r)[2], (r)[1], (r)[0], (u)[5], (u)[4], (u)[3], (u)[2], (u)[1], (u)[0], (v)[5], (v)[4], (v)[3], (v)[2], (v)[1], (v)[0])
#define NN_SUB_7(r, u, v) sub_dddddddmmmmmmmsssssss((r)[6], (r)[5], (r)[4], (r)[3], (r)[2], (r)[1], (r)[0], (u)[6], (u)[5], (u)[4], (u)[3], (u)[2], (u)[1], (u)[0], (v)[6], (v)[5], (v)[4], (v)[3], (v)[2], (v)[1], (v)[0])
#define NN_SUB_8(r, u, v) sub_ddddddddmmmmmmmmssssssss((r)[7], (r)[6], (r)[5], (r)[4], (r)[3], (r)[2], (r)[1], (r)[0], (u)[7], (u)[6], (u)[5], (u)[4], (u)[3], (u)[2], (u)[1], (u)[0], (v)[7], (v)[6], (v)[5], (v)[4], (v)[3], (v)[2], (v)[1], (v)[0])

#define DEF_SIGNED_SUB(n) \
FLINT_FORCE_INLINE int \
flint_mpn_signed_sub_ ## n(mp_ptr res, mp_srcptr x, mp_srcptr y) \
{ \
    if (mpn_cmp(x, y, n) >= 0) \
    { \
        NN_SUB_ ## n(res, x, y); \
        return 0; \
    } \
    else \
    { \
        NN_SUB_ ## n(res, y, x); \
        return 1; \
    } \
}

DEF_SIGNED_SUB(2)
DEF_SIGNED_SUB(3)
DEF_SIGNED_SUB(4)
DEF_SIGNED_SUB(5)
DEF_SIGNED_SUB(6)
DEF_SIGNED_SUB(7)
DEF_SIGNED_SUB(8)

FLINT_FORCE_INLINE void
flint_mpn_signed_div2(mp_ptr res, mp_srcptr x, mp_size_t n)
{
    mp_limb_t s = x[n - 1] & (UWORD(1) << (FLINT_BITS - 1));
    mpn_rshift(res, x, n, 1);
    res[n - 1] |= s;
}

void flint_mpn_mulmod_preinvn_2(mp_ptr r,
        mp_srcptr a, mp_srcptr b,
        mp_srcptr d, mp_srcptr dinv, ulong norm);

char * flint_mpn_get_str(char * res, int base, mp_srcptr x, mp_size_t xn, int negative);

#define MPN_NORM(a, an)                         \
    do {                                        \
        while ((an) != 0 && (a)[(an) - 1] == 0) \
           (an)--;                              \
    } while (0)

#define MPN_SWAP(a, an, b, bn) \
  do { \
    FLINT_SWAP(mp_ptr, a, b); \
    FLINT_SWAP(mp_size_t, an, bn); \
  } while (0)

#define BITS_TO_LIMBS(b) (((b) + GMP_NUMB_BITS - 1) / GMP_NUMB_BITS)

/* mpn macros for few-limb arithmetic ****************************************/

#define MPN_LEFT_SHIFT_HI(hi, lo, n) \
    ((n) > 0 ? (((hi) << (n)) | ((lo) >> (GMP_LIMB_BITS - (n)))) : (hi))

#define MPN_RIGHT_SHIFT_LOW(hi, lo, n) \
    ((n) > 0 ? (((lo) >> (n)) | ((hi) << (GMP_LIMB_BITS - (n)))) : (lo))

/* FLINT_MPN_MUL_2X1, FLINT_MPN_MUL_2X2, FLINT_MPN_MULLOW_2X2,
   FLINT_MPN_MUL_3P2X2 and FLINT_MPN_SQR_2X2 (products of one- and two-limb
   operands in registers) are in longlong.h */

/* {s0,s1,s2} = u[0]v[n-1] + u[1]v[n-2] + ... */
/* Assumes n >= 2 */
#define NN_DOTREV_S3_1X1(s2, s1, s0, u, v, n) \
    do { \
        mp_limb_t __dt0, __dt1, __ds0, __ds1, __ds2; \
        slong __i; \
        FLINT_ASSERT((n) >= 2); \
        umul_ppmm(__ds1, __ds0, (u)[0], (v)[(n) - 1]); \
        umul_ppmm(__dt1, __dt0, (u)[1], (v)[(n) - 2]); \
        add_sssaaaaaa(__ds2, __ds1, __ds0, 0, __ds1, __ds0, 0, __dt1, __dt0); \
        for (__i = 2; __i < (n); __i++) \
        { \
            umul_ppmm(__dt1, __dt0, (u)[__i], (v)[(n) - 1 - __i]); \
            add_sssaaaaaa(__ds2, __ds1, __ds0, __ds2, __ds1, __ds0, 0, __dt1, __dt0); \
        } \
        (s0) = __ds0; (s1) = __ds1; (s2) = __ds2; \
    } while (0) \

/* Like NN_DOTREV_S3_1X1 but summing only over the high parts of the products. */
#define NN_DOTREV_S3_1X1_HIGH(s2, s1, u, v, n) \
    do { \
        mp_limb_t __dt1, __ds1, __ds2; \
        slong __i; \
        FLINT_ASSERT((n) >= 2); \
        __ds1 = n_mulhi((u)[0], (v)[(n) - 1]); \
        __dt1 = n_mulhi((u)[1], (v)[(n) - 2]); \
        add_ssaaaa(__ds2, __ds1, 0, __ds1, 0, __dt1); \
        for (__i = 2; __i < (n); __i++) \
        { \
            __dt1 = n_mulhi((u)[__i], (v)[(n) - 1 - __i]); \
            add_ssaaaa(__ds2, __ds1, __ds2, __ds1, 0, __dt1); \
        } \
        (s1) = __ds1; (s2) = __ds2; \
    } while (0) \

/* {r0,r1,r2} = {s0,s1,s2} + u[0]v[n-1] + u[1]v[n-2] + ... */
/* Assumes n >= 1. May have s2 != 0, but the final sum is assumed to fit in 3 limbs. */
#define NN_DOTREV_S3_A3_1X1(r2, r1, r0, s2, s1, s0, u, v, n) \
    do { \
        mp_limb_t __dt0, __dt1, __ds0, __ds1, __ds2; \
        slong __i; \
        FLINT_ASSERT((n) >= 1); \
        __ds0 = (s0); __ds1 = (s1); __ds2 = (s2); \
        for (__i = 0; __i < (n); __i++) \
        { \
            umul_ppmm(__dt1, __dt0, (u)[__i], (v)[(n) - 1 - __i]); \
            add_sssaaaaaa(__ds2, __ds1, __ds0, __ds2, __ds1, __ds0, 0, __dt1, __dt0); \
        } \
        (r0) = __ds0; (r1) = __ds1; (r2) = __ds2; \
    } while (0) \

#define NN_MUL_1X1 umul_ppmm

/* {r0,r1} = {s0,s1} + x * y, with no carry-out. */
#define NN_ADDMUL_S2_A2_1X1(r1, r0, s1, s0, x, y) \
    do { \
        mp_limb_t __dt0, __dt1; \
        umul_ppmm(__dt1, __dt0, (x), (y)); \
        add_ssaaaa(r1, r0, s1, s0, __dt1, __dt0); \
    } while (0); \


/* addition ******************************************************************/

#if FLINT_HAVE_ASSEMBLY_x86_64_adx
/* Simultaneously adds two n-limbed integers onto result and returns carry. */
/* NOTE: Requires n >= 4 */
# define FLINT_HAVE_NATIVE_mpn_2add_n_inplace 1
mp_limb_t flint_mpn_2add_n_inplace(mp_ptr, mp_srcptr, mp_srcptr, mp_size_t);
#endif

#if FLINT_HAVE_NATIVE_mpn_add_nc
# define mpn_add_nc __gmpn_add_nc
mp_limb_t mpn_add_nc(mp_ptr, mp_srcptr, mp_srcptr, mp_size_t, mp_limb_t);
#else
FLINT_FORCE_INLINE mp_limb_t
mpn_add_nc(mp_ptr rp, mp_srcptr up, mp_srcptr vp, mp_size_t n, mp_limb_t ci)
{
    mp_limb_t co;
    co = mpn_add_n(rp, up, vp, n);
    co += mpn_add_1(rp, rp, n, ci);
    return co;
}
#endif

#if FLINT_HAVE_NATIVE_mpn_sub_nc
# define mpn_sub_nc __gmpn_sub_nc
mp_limb_t mpn_sub_nc(mp_ptr, mp_srcptr, mp_srcptr, mp_size_t, mp_limb_t);
#else
FLINT_FORCE_INLINE mp_limb_t
mpn_sub_nc(mp_ptr rp, mp_srcptr up, mp_srcptr vp, mp_size_t n, mp_limb_t ci)
{
    mp_limb_t co;
    co = mpn_sub_n(rp, up, vp, n);
    co += mpn_sub_1(rp, rp, n, ci);
    return co;
}
#endif

#if FLINT_HAVE_NATIVE_mpn_add_n_sub_n
/* mpn_add_n_sub_n basically only exists for IA64 and certain PowerPC and s390
 * systems. We will assume that a native one does not exist. */
# undef FLINT_HAVE_NATIVE_mpn_add_n_sub_n
# define FLINT_HAVE_NATIVE_mpn_add_n_sub_n 0
#endif

mp_limb_t flint_mpn_sumdiff_n(mp_ptr s, mp_ptr d, mp_srcptr x, mp_srcptr y, mp_size_t n);

/* shifting ******************************************************************/

#if FLINT_HAVE_NATIVE_mpn_addlsh1_n
# define mpn_addlsh1_n __gmpn_addlsh1_n
mp_limb_t mpn_addlsh1_n(mp_ptr, mp_srcptr, mp_srcptr, mp_size_t);
#endif

#if FLINT_HAVE_NATIVE_mpn_addlsh1_n_ip1
# define mpn_addlsh1_n_ip1 __gmpn_addlsh1_n_ip1
mp_limb_t mpn_addlsh1_n_ip1(mp_ptr, mp_srcptr, mp_srcptr, mp_size_t);
#elif FLINT_HAVE_NATIVE_mpn_addlsh1_n
# define mpn_addlsh1_n_ip1(a,b,n) mpn_addlsh1_n(a,a,b,n)
# define FLINT_HAVE_NATIVE_mpn_addlsh1_n_ip1 2
#endif

#if FLINT_HAVE_NATIVE_mpn_rsh1add_n
# define mpn_rsh1add_n __gmpn_rsh1add_n
mp_limb_t mpn_rsh1add_n(mp_ptr, mp_srcptr, mp_srcptr, mp_size_t);
#endif

#if FLINT_HAVE_NATIVE_mpn_rsh1sub_n
# define mpn_rsh1sub_n __gmpn_rsh1sub_n
mp_limb_t mpn_rsh1sub_n(mp_ptr, mp_srcptr, mp_srcptr, mp_size_t);
#endif

/* multiplication (general) **************************************************/

#if FLINT_HAVE_ASSEMBLY_x86_64_adx
# define FLINT_MPN_MUL_FUNC_TAB_WIDTH 17
# define FLINT_MPN_SQR_FUNC_TAB_WIDTH 14

# define FLINT_HAVE_MUL_FUNC(n, m) ((n) <= 16)
# define FLINT_HAVE_MUL_N_FUNC(n) ((n) <= 16)
# define FLINT_HAVE_SQR_FUNC(n) ((n) <= FLINT_MPN_SQR_FUNC_TAB_WIDTH)

# define FLINT_MPN_MUL_HARD(rp, xp, xn, yp, yn) (flint_mpn_mul_func_tab[xn][yn](rp, xp, yp))
# define FLINT_MPN_MUL_N_HARD(rp, xp, yp, n) (flint_mpn_mul_n_func_tab[n](rp, xp, yp))
# define FLINT_MPN_SQR_HARD(rp, xp, n) (flint_mpn_sqr_func_tab[n](rp, xp))
#elif FLINT_HAVE_ASSEMBLY_armv8
# define FLINT_MPN_MUL_FUNC_N_TAB_WIDTH 15
# define FLINT_MPN_SQR_FUNC_TAB_WIDTH 9

# define FLINT_HAVE_MUL_FUNC(n, m) FLINT_HAVE_MUL_N_FUNC(n)
# define FLINT_HAVE_MUL_N_FUNC(n) ((n) <= FLINT_MPN_MUL_FUNC_N_TAB_WIDTH)
# define FLINT_HAVE_SQR_FUNC(n) ((n) <= FLINT_MPN_SQR_FUNC_TAB_WIDTH)

# define FLINT_MPN_MUL_HARD(rp, xp, xn, yp, yn) (flint_mpn_mul_func_n_tab[xn](rp, xp, yp, yn))
# define FLINT_MPN_MUL_N_HARD(rp, xp, yp, n) (flint_mpn_mul_func_n_tab[n](rp, xp, yp, n))
# define FLINT_MPN_SQR_HARD(rp, xp, n) (flint_mpn_sqr_func_tab[n](rp, xp))

# define FLINT_HAVE_NATIVE_mpn_mul_2 1
mp_limb_t flint_mpn_mul_2(mp_ptr, mp_srcptr, mp_size_t, mp_srcptr);
#else
# define FLINT_MPN_MUL_FUNC_TAB_WIDTH 8
# define FLINT_MPN_SQR_FUNC_TAB_WIDTH 0

# define FLINT_HAVE_MUL_FUNC(n, m) ((n) <= 7 || ((n) <= 14 && (m) == 1))
# define FLINT_HAVE_MUL_N_FUNC(n) ((n) <= 7)
# define FLINT_HAVE_SQR_FUNC(n) (0)

# define FLINT_MPN_MUL_HARD(rp, xp, xn, yp, yn) (flint_mpn_mul_func_tab[xn][yn](rp, xp, yp))
# define FLINT_MPN_MUL_N_HARD(rp, xp, yp, n) (flint_mpn_mul_n_func_tab[n](rp, xp, yp))
# define FLINT_MPN_SQR_HARD(rp, xp, n) (flint_mpn_sqr_func_tab[n](rp, xp))
#endif

#define FLINT_MUL_USE_FUNC_TAB 1

typedef mp_limb_t (* flint_mpn_mul_func_t)(mp_ptr, mp_srcptr, mp_srcptr);
typedef mp_limb_t (* flint_mpn_mul_func_n_t)(mp_ptr, mp_srcptr, mp_srcptr, mp_size_t);
typedef mp_limb_t (* flint_mpn_sqr_func_t)(mp_ptr, mp_srcptr);

#ifdef FLINT_MPN_MUL_FUNC_N_TAB_WIDTH
FLINT_DLL extern const flint_mpn_mul_func_n_t flint_mpn_mul_func_n_tab[];
#else
FLINT_DLL extern const flint_mpn_mul_func_t flint_mpn_mul_func_tab[][FLINT_MPN_MUL_FUNC_TAB_WIDTH];
FLINT_DLL extern const flint_mpn_mul_func_t flint_mpn_mul_n_func_tab[];
#endif

FLINT_DLL extern const flint_mpn_sqr_func_t flint_mpn_sqr_func_tab[];

void flint_mpn_mul_toom22(mp_ptr pp, mp_srcptr ap, mp_size_t an, mp_srcptr bp, mp_size_t bn, mp_ptr scratch);
void flint_mpn_mul_toom32(mp_ptr pp, mp_srcptr ap, mp_size_t an, mp_srcptr bp, mp_size_t bn, mp_ptr scratch);

mp_limb_t _flint_mpn_mul(mp_ptr r, mp_srcptr x, mp_size_t xn, mp_srcptr y, mp_size_t yn);
void _flint_mpn_mul_n(mp_ptr r, mp_srcptr x, mp_srcptr y, mp_size_t n);
mp_limb_t _flint_mpn_sqr(mp_ptr r, mp_srcptr x, mp_size_t n);

MPN_EXTRAS_INLINE mp_limb_t
flint_mpn_mul(mp_ptr r, mp_srcptr x, mp_size_t xn, mp_srcptr y, mp_size_t yn)
{
    FLINT_ASSERT(xn >= yn);
    FLINT_ASSERT(yn >= 1);
    FLINT_ASSERT(r != x);
    FLINT_ASSERT(r != y);

    if (yn > xn)
        FLINT_UNREACHABLE;

    if (FLINT_MUL_USE_FUNC_TAB && FLINT_HAVE_MUL_FUNC(xn, yn))
        return FLINT_MPN_MUL_HARD(r, x, xn, y, yn);
    else
        return _flint_mpn_mul(r, x, xn, y, yn);
}

MPN_EXTRAS_INLINE void
flint_mpn_mul_n(mp_ptr r, mp_srcptr x, mp_srcptr y, mp_size_t n)
{
    FLINT_ASSERT(n >= 1);
    FLINT_ASSERT(r != x);
    FLINT_ASSERT(r != y);

    if (FLINT_MUL_USE_FUNC_TAB && FLINT_HAVE_MUL_N_FUNC(n))
        FLINT_MPN_MUL_N_HARD(r, x, y, n);
    else
        _flint_mpn_mul_n(r, x, y, n);
}

MPN_EXTRAS_INLINE mp_limb_t
flint_mpn_sqr(mp_ptr r, mp_srcptr x, mp_size_t n)
{
    FLINT_ASSERT(n >= 1);

    if (FLINT_MUL_USE_FUNC_TAB && FLINT_HAVE_SQR_FUNC(n))
    {
        /* NOTE: Aliasing allowed */
        return FLINT_MPN_SQR_HARD(r, x, n);
    }
    else
    {
        FLINT_ASSERT(r != x);
        return _flint_mpn_sqr(r, x, n);
    }
}

/* z1 = a x (an + xn limbs) and z2 = b x (bn + xn limbs), the
   operands in any order of lengths (all >= 1); with fft_small the
   transform of x is shared when both products are long enough
   (_flint_mpn_mul_shared_use_fft), else two products are formed. The
   outputs must not overlap each other or the inputs. */
void flint_mpn_mul_shared(mp_ptr z1, mp_srcptr a, mp_size_t an,
    mp_ptr z2, mp_srcptr b, mp_size_t bn, mp_srcptr x, mp_size_t xn);
int _flint_mpn_mul_shared_use_fft(mp_size_t an, mp_size_t bn,
    mp_size_t xn);

/* Like flint_mpn_mul but allow operands in either order, completely
   inline some small products, and also check for squaring. */
#define FLINT_MPN_MUL_WITH_SPECIAL_CASES(_z, _x, _xn, _y, _yn) \
    if ((_xn) == (_yn)) \
    { \
        if ((_xn) == 1) \
        { \
            umul_ppmm((_z)[1], (_z)[0], (_x)[0], (_y)[0]); \
        } \
        else if ((_xn) == 2) \
        { \
            mp_limb_t __tt_x1, __tt_x0, __tt_y1, __tt_y0; \
            __tt_x0 = (_x)[0]; \
            __tt_x1 = (_x)[1]; \
            __tt_y0 = (_y)[0]; \
            __tt_y1 = (_y)[1]; \
            FLINT_MPN_MUL_2X2((_z)[3], (_z)[2], (_z)[1], (_z)[0], __tt_x1, __tt_x0, __tt_y1, __tt_y0); \
        } \
        else if ((_x) == (_y)) \
            flint_mpn_sqr((_z), (_x), (_xn)); \
        else \
            flint_mpn_mul_n((_z), (_x), (_y), (_xn)); \
    } \
    else if ((_xn) > (_yn)) \
    { \
        flint_mpn_mul((_z), (_x), (_xn), (_y), (_yn)); \
    } \
    else \
    { \
        flint_mpn_mul((_z), (_y), (_yn), (_x), (_xn)); \
    }

/* High, low and middle multiplication *******************************************************/

#define FLINT_HAVE_MULLOW_FUNC(n) ((n) <= FLINT_MPN_MULLOW_FUNC_TAB_WIDTH)
#define FLINT_HAVE_MULHIGH_FUNC(n) ((n) <= FLINT_MPN_MULHIGH_FUNC_TAB_WIDTH)
#define FLINT_HAVE_SQRHIGH_FUNC(n) ((n) <= FLINT_MPN_SQRHIGH_FUNC_TAB_WIDTH)
#define FLINT_HAVE_MULHIGH_NORMALISED_FUNC(n) ((n) <= FLINT_MPN_MULHIGH_NORMALISED_FUNC_TAB_WIDTH)
#define FLINT_HAVE_SQRHIGH_NORMALISED_FUNC(n) ((n) <= FLINT_MPN_SQRHIGH_NORMALISED_FUNC_TAB_WIDTH)

typedef struct { mp_limb_t m1; mp_limb_t m2; } mp_limb_pair_t;
typedef mp_limb_pair_t (* flint_mpn_sqrhigh_normalised_func_t)(mp_ptr, mp_srcptr);
typedef mp_limb_pair_t (* flint_mpn_mulhigh_normalised_func_t)(mp_ptr, mp_srcptr, mp_srcptr);

FLINT_DLL extern const flint_mpn_mul_func_t flint_mpn_mullow_func_tab[];
FLINT_DLL extern const flint_mpn_mul_func_t flint_mpn_mulhigh_func_tab[];
FLINT_DLL extern const flint_mpn_sqr_func_t flint_mpn_sqrhigh_func_tab[];
FLINT_DLL extern const flint_mpn_mulhigh_normalised_func_t flint_mpn_mulhigh_normalised_func_tab[];
FLINT_DLL extern const flint_mpn_sqrhigh_normalised_func_t flint_mpn_sqrhigh_normalised_func_tab[];

#if FLINT_HAVE_ASSEMBLY_x86_64_adx
# define FLINT_MPN_MULLOW_FUNC_TAB_WIDTH 8
# define FLINT_MPN_MULHIGH_FUNC_TAB_WIDTH 13
/* n with best effective cycles/limb (and current largest assembly case) -- used by mulhigh_recursive */
# define FLINT_MPN_MULHIGH_BEST_TAB_N 9
# define FLINT_MPN_SQRHIGH_FUNC_TAB_WIDTH 8
# define FLINT_MPN_MULHIGH_NORMALISED_FUNC_TAB_WIDTH 9
# define FLINT_MPN_SQRHIGH_NORMALISED_FUNC_TAB_WIDTH 8

# define FLINT_HAVE_NATIVE_mpn_mullow_basecase 1
/* NOTE: This function only works for n >= 6 */
# define FLINT_HAVE_NATIVE_mpn_mulhigh_basecase 1
/* NOTE: This function only works for n >= 6 */
# define FLINT_HAVE_NATIVE_mpn_sqrhigh_basecase 1

#elif FLINT_HAVE_ASSEMBLY_armv8
# define FLINT_MPN_MULLOW_FUNC_TAB_WIDTH 0
# define FLINT_MPN_MULHIGH_FUNC_TAB_WIDTH 8
# define FLINT_MPN_MULHIGH_BEST_TAB_N 8
# define FLINT_MPN_SQRHIGH_FUNC_TAB_WIDTH 8
# define FLINT_MPN_MULHIGH_NORMALISED_FUNC_TAB_WIDTH 0
# define FLINT_MPN_SQRHIGH_NORMALISED_FUNC_TAB_WIDTH 0

/* NOTE: This function only works for n > 8 */
# define FLINT_HAVE_NATIVE_mpn_mulhigh_basecase 1

#else
/* TODO: generic hardcoded mullows */
# define FLINT_MPN_MULLOW_FUNC_TAB_WIDTH 0
# define FLINT_MPN_MULHIGH_FUNC_TAB_WIDTH 16
# define FLINT_MPN_MULHIGH_BEST_TAB_N 16
# define FLINT_MPN_SQRHIGH_FUNC_TAB_WIDTH 2
# define FLINT_MPN_MULHIGH_NORMALISED_FUNC_TAB_WIDTH 0
# define FLINT_MPN_SQRHIGH_NORMALISED_FUNC_TAB_WIDTH 0

#endif

/* FIXME: this tuning is for x86_64_adx with fft_small */
/* FIXME: we currently assume that the same parameters are optimal for both mulhigh and mullow */
#define FLINT_MPN_MULLOW_MULDERS_CUTOFF 50
#define FLINT_MPN_MULHIGH_MULDERS_CUTOFF 40
#define FLINT_MPN_MULHIGH_MUL_CUTOFF 2000
#define FLINT_MPN_MULHIGH_K_TAB_SIZE 2048

#define FLINT_MPN_SQRHIGH_MULDERS_CUTOFF 90
#define FLINT_MPN_SQRHIGH_SQR_CUTOFF 2000
#define FLINT_MPN_SQRHIGH_K_TAB_SIZE 2048

/* Error bounds (in ulp of the returned guard limb, i.e. of limb n - 1 of
   the 2n-limb product) of the precise high products flint_mpn_mulhigh_n
   and flint_mpn_sqrhigh_n: the computed n + 1 limbs never exceed the exact
   ones and fall short of them by at most this amount.

   All backends accumulate every partial-product limb landing in columns
   n - 1 and above (the low halves of the products on the diagonal
   p + q = n - 2 are dropped, as is everything below). The dropped amount
   D satisfies D / B^(n-1) < (n - 1)(1 - 1/B) + (n - 2)(1 - 1/B)^2 +
   (n - 3)/B < 2n - 3 (Ahlback and Johansson, "Fast basecases for
   arbitrary-size multiplication"), so the integer deficit, which is
   floor(D / B^(n-1)), is at most 2n - 4. This is attained: the inputs
   x_i = B - 2^(FLINT_BITS/2) - 1, y_i = B - 2^(FLINT_BITS/2) + 1 give
   exactly 2n - 4 (the low half of each product on the diagonal is B - 1,
   and the products below are nearly maximal). The exact 1- and 2-limb
   kernels have no error. For the normalised variants the shift doubles
   the deficit and can add one unit. */
#define FLINT_MPN_MULHIGH_N_GUARD_ERR_BOUND(n) ((n) <= 2 ? 0 : 2 * (n) - 4)
#define FLINT_MPN_SQRHIGH_N_GUARD_ERR_BOUND(n) FLINT_MPN_MULHIGH_N_GUARD_ERR_BOUND(n)
#define FLINT_MPN_MULHIGH_N_NORMALISED_GUARD_ERR_BOUND(n) (2 * FLINT_MPN_MULHIGH_N_GUARD_ERR_BOUND(n) + 1)
#define FLINT_MPN_SQRHIGH_N_NORMALISED_GUARD_ERR_BOUND(n) FLINT_MPN_MULHIGH_N_NORMALISED_GUARD_ERR_BOUND(n)

/* The same bounds for the general high products flint_mpn_mulhigh and
   flint_mpn_sqrhigh (top n limbs of a product of any shape plus a guard
   limb): the shapes reduce to the balanced ones, with operands longer than
   n limbs truncated at a cost below 3 units of the guard limb each after
   the leading correction term is added back (see mulhigh_general.c), so
   the deficit stays below (2n - 3) + 6. */
#define FLINT_MPN_MULHIGH_GUARD_ERR_BOUND(n) (2 * (n) + 4)
#define FLINT_MPN_SQRHIGH_GUARD_ERR_BOUND(n) FLINT_MPN_MULHIGH_GUARD_ERR_BOUND(n)
#define FLINT_MPN_MULHIGH_NORMALISED_GUARD_ERR_BOUND(n) (2 * FLINT_MPN_MULHIGH_GUARD_ERR_BOUND(n) + 1)
#define FLINT_MPN_SQRHIGH_NORMALISED_GUARD_ERR_BOUND(n) FLINT_MPN_MULHIGH_NORMALISED_GUARD_ERR_BOUND(n)

/* General high products: the top n limbs of x * y (resp. x^2), written to
   res, and the limb below them, returned, as a lower approximation with
   deficit at most FLINT_MPN_MULHIGH_GUARD_ERR_BOUND(n) units of the
   returned limb; the product is zero padded above if it is shorter than
   n + 1 limbs. The normalised variants also shift the result left by one
   bit when its top bit is clear, as flint_mpn_mulhigh_n_normalised. res
   may be one of the operands (all the high products allow this). */
mp_limb_t flint_mpn_mulhigh(mp_ptr res, mp_srcptr x, mp_size_t xn, mp_srcptr y, mp_size_t yn, mp_size_t n);
mp_limb_t flint_mpn_sqrhigh(mp_ptr res, mp_srcptr x, mp_size_t xn, mp_size_t n);
mp_limb_pair_t flint_mpn_mulhigh_normalised(mp_ptr res, mp_srcptr x, mp_size_t xn, mp_srcptr y, mp_size_t yn, mp_size_t n);
mp_limb_pair_t flint_mpn_sqrhigh_normalised(mp_ptr res, mp_srcptr x, mp_size_t xn, mp_size_t n);

/* Whether the product of xn x yn limbs of which the top n limbs are
   wanted should be computed in full rather than as a high product: nearly
   all of it is wanted, or no operand is longer than the output and the
   high product would be a full product internally (in the range of the
   hardcoded kernels, or both operands shorter than the output and not
   nearly balanced, cf. mulhigh_general.c, whose fallback length this
   matches); never for the balanced shape xn = yn = n, which has its own
   kernels. */
FLINT_FORCE_INLINE int
_flint_mpn_mulhigh_prefer_full(slong xn, slong yn, slong n)
{
    slong zn = xn + yn;

    if (zn <= n + FLINT_MAX(2, n / 16))
        return 1;

    if (xn == n && yn == n)
        return 0;

    /* a short factor (a coefficient of a few limbs) times one not longer
       than the output: the high product could only skip a triangle of at
       most 1/8 of the work (1/4 for outputs of up to 64 limbs), less than
       its normalisation and copies */
    if (FLINT_MAX(xn, yn) <= n + 1 &&
        (4 * FLINT_MIN(xn, yn) <= n || (n <= 64 && 2 * FLINT_MIN(xn, yn) <= n)))
        return 1;

    if (xn <= n && yn <= n)
    {
        if (n <= FLINT_MPN_MULHIGH_FUNC_TAB_WIDTH)
            return 1;
        if (xn < n && yn < n && 8 * FLINT_MIN(xn, yn) < 7 * n)
            return 1;
    }

    return 0;
}

/* Dot products with fixed limb sizes *****************************************/

/*
   Kernels computing {res, s} = sum_{k=0}^{len-1} a_k * b_k mod 2^(FLINT_BITS*s)
   where the a_k are n1-limb and the b_k are n2-limb integers, with
   n1 >= n2 and s in {n1+n2-1, n1+n2, n1+n2+1}:

     _mpn_dot_{n1}x{n2}_{s}(res, a, b, len)           forward: contiguous arrays
     _mpn_dot_rev_{n1}x{n2}_{s}(res, a, b, len)       reversed: b_k = b[len-1-k]
     _mpn_dot_strided_{n1}x{n2}_{s}(res, a, astride, b, bstride, len)
                                                      strides in limbs (may be negative)

   The plain versions assume unsigned inputs, the _signed versions two's
   complement inputs (with sign in the top limb). The output is exact
   provided that the true result fits in s limbs (as an unsigned respectively
   two's complement number). Dedicated forward and reversed kernels exist
   for n1 <= 2; for n1 = 3, 4 they are inline wrappers around the strided
   kernels. Generated by dev/gen_mpn_dot_rev.py.
*/

typedef void (* flint_mpn_dot_func_t)(nn_ptr, nn_srcptr, nn_srcptr, slong);
typedef void (* flint_mpn_dot_strided_func_t)(nn_ptr, nn_srcptr, slong, nn_srcptr, slong, slong);

#define FLINT_MPN_DOT_TAB_N 4
#define FLINT_MPN_DOT_DEDICATED_TAB_N 2

/* Tables indexed [sgn][n1][n2][s - (n1 + n2 - 1)], with NULL where no kernel
   exists (in particular when n1 < n2). */
FLINT_DLL extern const flint_mpn_dot_strided_func_t flint_mpn_dot_strided_tab[2][FLINT_MPN_DOT_TAB_N + 1][FLINT_MPN_DOT_TAB_N + 1][3];
FLINT_DLL extern const flint_mpn_dot_func_t flint_mpn_dot_tab[2][FLINT_MPN_DOT_DEDICATED_TAB_N + 1][FLINT_MPN_DOT_DEDICATED_TAB_N + 1][3];
FLINT_DLL extern const flint_mpn_dot_func_t flint_mpn_dot_rev_tab[2][FLINT_MPN_DOT_DEDICATED_TAB_N + 1][FLINT_MPN_DOT_DEDICATED_TAB_N + 1][3];

/* Fixed-size inlined multiplication/squaring loops over packed
   coefficients, with the window semantics of _flint_mpn_poly_mulmid
   (see poly_mul.c); the kernels themselves are static in
   poly_mulmid_kernels.c and only reachable through these tables,
   indexed like the dot product tables (the signmag tables have no sign
   dimension). Generated by dev/gen_mpn_dot_rev.py. */
typedef void (* flint_mpn_poly_mulmid_func_t)(nn_ptr, nn_srcptr, slong, nn_srcptr, slong, slong, slong);
typedef void (* flint_mpn_poly_sqrmid_func_t)(nn_ptr, nn_srcptr, slong, slong, slong);

FLINT_DLL extern const flint_mpn_poly_mulmid_func_t flint_mpn_poly_mulmid_tab[2][4][4][3];
FLINT_DLL extern const flint_mpn_poly_sqrmid_func_t flint_mpn_poly_sqrmid_tab[2][4][4][3];
FLINT_DLL extern const flint_mpn_poly_mulmid_func_t flint_mpn_poly_mulmid_short_tab[2][5][5][3];
FLINT_DLL extern const flint_mpn_poly_sqrmid_func_t flint_mpn_poly_sqrmid_short_tab[2][5][5][3];
FLINT_DLL extern const flint_mpn_poly_mulmid_func_t flint_mpn_poly_mulmid_signmag_tab[5][5][3];
FLINT_DLL extern const flint_mpn_poly_sqrmid_func_t flint_mpn_poly_sqrmid_signmag_tab[5][5][3];

/* Generic versions for any n1 >= n2 >= 1 and s in {n1+n2-1, n1+n2, n1+n2+1}.
   The scratch space must have at least n1 + n2 limbs. These are inline
   since they are called in inner loops with very short lengths. */
/* Version with sdiff = s - (n1 + n2 - 1) in {0, 1, 2}, which should be
   a compile-time constant for best performance. */
MPN_EXTRAS_INLINE void
_flint_mpn_dot_rev_generic_sdiff(nn_ptr res, nn_srcptr a, slong n1, nn_srcptr b, slong n2, slong len, int sdiff, nn_ptr t)
{
    slong k, m = n1 + n2;

    FLINT_ASSERT(n1 >= n2 && n2 >= 1 && len >= 1 && sdiff >= 0 && sdiff <= 2);

    b += (len - 1) * n2;

    if (sdiff >= 1)
    {
        flint_mpn_mul(res, a, n1, b, n2);
        if (sdiff == 2)
            res[m] = 0;

        for (k = 1; k < len; k++)
        {
            a += n1;
            b -= n2;
            flint_mpn_mul(t, a, n1, b, n2);
            if (sdiff == 1)
                mpn_add_n(res, res, t, m);
            else
                res[m] += mpn_add_n(res, res, t, m);
        }
    }
    else
    {
        flint_mpn_mul(t, a, n1, b, n2);
        flint_mpn_copyi(res, t, m - 1);

        for (k = 1; k < len; k++)
        {
            a += n1;
            b -= n2;
            flint_mpn_mul(t, a, n1, b, n2);
            mpn_add_n(res, res, t, m - 1);
        }
    }
}

MPN_EXTRAS_INLINE void
_flint_mpn_dot_rev_generic(nn_ptr res, nn_srcptr a, slong n1, nn_srcptr b, slong n2, slong len, slong s, nn_ptr t)
{
    _flint_mpn_dot_rev_generic_sdiff(res, a, n1, b, n2, len, (int) (s - (n1 + n2 - 1)), t);
}

void _flint_mpn_dot_rev_generic_signed(nn_ptr res, nn_srcptr a, slong n1, nn_srcptr b, slong n2, slong len, slong s, nn_ptr scratch);

/* Sign-magnitude version: each coefficient is a sign limb (0 or 1) followed
   by the magnitude with n1 resp. n2 limbs, so that the arrays have strides
   n1 + 1 and n2 + 1. The output is two's complement. Requires scratch space
   of n1 + n2 + 2 s limbs. */
MPN_EXTRAS_INLINE void
_flint_mpn_dot_rev_generic_signmag(nn_ptr res, nn_srcptr a, slong n1, nn_srcptr b, slong n2, slong len, slong s, nn_ptr t)
{
    slong k, m = n1 + n2;
    nn_ptr acc = t + m;     /* positive and negative sums, s limbs each */

    FLINT_ASSERT(n1 >= n2 && n2 >= 1 && len >= 1 && s >= m - 1 && s <= m + 1);

    flint_mpn_zero(acc, 2 * s);
    b += (len - 1) * (n2 + 1);

    for (k = 0; k < len; k++)
    {
        nn_ptr dst = acc + (a[0] ^ b[0]) * s;

        flint_mpn_mul(t, a + 1, n1, b + 1, n2);

        if (s >= m)
        {
            ulong cy = mpn_add_n(dst, dst, t, m);
            if (s > m)
                dst[m] += cy;
        }
        else
            mpn_add_n(dst, dst, t, s);

        a += n1 + 1;
        b -= n2 + 1;
    }

    mpn_sub_n(res, acc, acc + s, s);
}

/* Polynomial multiplication with fixed limb sizes ***************************/

/*
   Multiplication of polynomials with fixed-size coefficients (unsigned if
   sgn = 0, two's complement if sgn = 1), with output coefficients of s
   limbs computed mod 2^(FLINT_BITS s). See the documentation for the
   exactness conditions.
*/

/* Coefficients [nlo, nhi) of the product of {f, flen n1} and {g, glen n2},
   n1 >= n2, s in {n1+n2-1, n1+n2, n1+n2+1}. */

/* sgn = 0: unsigned, 1: two's complement, 2: sign-magnitude (each coefficient
   a sign limb followed by n1 resp. n2 magnitude limbs; the output is two's
   complement). */
void _flint_mpn_poly_mulmid_classical(nn_ptr res, nn_srcptr f, slong flen, slong n1, nn_srcptr g, slong glen, slong n2, slong nlo, slong nhi, slong s, int sgn);

MPN_EXTRAS_INLINE void
_flint_mpn_poly_mul_classical(nn_ptr res, nn_srcptr f, slong flen, nn_srcptr g, slong glen, slong nlimbs, slong slimbs, int sgn)
{
    _flint_mpn_poly_mulmid_classical(res, f, flen, nlimbs, g, glen, nlimbs, 0, flen + glen - 1, slimbs, sgn);
}

void _flint_mpn_poly_mul_karatsuba(nn_ptr res, nn_srcptr f, slong flen, nn_srcptr g, slong glen, slong nlimbs, slong slimbs, slong cutoff, int norm, int sgn);

/* Coefficients [nlo, nhi) of the product, using Karatsuba-based algorithms
   (full, Mulders' short products, or the Karatsuba middle product) depending
   on the shape. The operands may have different numbers of limbs, with
   norm1 and norm2 their respective headroom. The Karatsuba middle product
   uses two's complement arithmetic internally, so slimbs must include a
   sign bit even for unsigned inputs; slimbs must be at least
   nlimbs1 + nlimbs2 - 1 and, if either operand may get extended in the
   recursion (when its headroom is smaller than the recursion depth plus
   one), at least nlimbs1 + nlimbs2 + 1. */
/* Length below which classical multiplication is used instead of Karatsuba,
   for coefficients of n1 and n2 limbs (tuned on x86_64). Short and middle
   products use a larger cutoff internally. */
MPN_EXTRAS_INLINE slong
_flint_mpn_poly_karatsuba_cutoff(slong n1, slong n2, int squaring)
{
    slong m = n1 * n2;

    if (squaring)
    {
        /* (Karatsuba gains less over the classical squaring, which
           computes only half the products; measured with residues
           filling the top limb, where the sums get extended) */
        if (m <= 4) return 64;
        if (m <= 16) return 32;
        return 8;
    }
    else
    {
        if (m <= 4) return 32;
        if (m <= 9) return 16;
        if (m <= 16) return 8;
        if (m <= 25) return 6;
        return 4;
    }
}

/* Whether the Karatsuba recursion may need to extend an operand with the
   given headroom by a limb, given the shorter length and the cutoff. */
MPN_EXTRAS_INLINE int
_flint_mpn_poly_karatsuba_may_extend(slong norm, slong minlen, slong cutoff)
{
    return minlen >= cutoff && norm < (slong) FLINT_BIT_COUNT(minlen) + 1;
}

/* Representations of the packed coefficients for _flint_mpn_poly_mulmid. */
#define FLINT_MPN_POLY_MUL_UNSIGNED 0   /* nonnegative, zero-extended */
#define FLINT_MPN_POLY_MUL_SIGNED 1     /* two's complement */
#define FLINT_MPN_POLY_MUL_SIGNMAG 2    /* sign limb followed by the magnitude (classical only) */
#define FLINT_MPN_POLY_MUL_BIAS 3       /* x + 2^bits for the operands with negative
                                     coefficients, computed as unsigned; the
                                     caller corrects the outputs */

/* Packing parameters chosen by _flint_mpn_poly_mulmid_params. */
typedef struct
{
    int method;
    slong nlimbs1;
    slong norm1;
    slong nlimbs2;
    slong norm2;
    slong slimbs;
}
mpn_poly_mul_params_struct;

typedef mpn_poly_mul_params_struct mpn_poly_mul_params_t[1];

/* Tuning knobs (for tests and profiling): force a representation or a
   Karatsuba cutoff (-1 = automatic). */
FLINT_DLL extern int _flint_mpn_poly_mulmid_force_method;
FLINT_DLL extern slong _flint_mpn_poly_mulmid_force_cutoff;

/* The Karatsuba cutoff used by _flint_mpn_poly_mulmid. */
slong _flint_mpn_poly_mulmid_cutoff(slong nlimbs1, slong nlimbs2, int squaring);

/* Whether _flint_mpn_poly_mulmid uses Karatsuba for dot products of minlen
   terms with the given cutoff: not for sign-magnitude coefficients, and
   with tight headroom (the coefficients would get extended by a limb,
   which costs about ((m+1)/m)^2 in the sub-products) only from one and a
   half times the cutoff. */
MPN_EXTRAS_INLINE int
_flint_mpn_poly_mulmid_use_karatsuba(slong minlen, slong norm, int method, slong cutoff)
{
    if (method == FLINT_MPN_POLY_MUL_SIGNMAG || minlen < cutoff)
        return 0;
    if (_flint_mpn_poly_karatsuba_may_extend(norm, minlen, cutoff) && minlen < cutoff + cutoff / 2)
        return 0;
    return 1;
}

/* Number of output limbs required by _flint_mpn_poly_mulmid for dot products of
   at most minlen terms of the given operands, with the given cutoff
   (inline so that a constant cutoff, e.g. WORD_MAX for the classical
   bound, folds away in the callers). */
MPN_EXTRAS_INLINE slong
_flint_mpn_poly_mulmid_slimbs(slong minlen, slong nlimbs1, slong norm1, slong nlimbs2, slong norm2, int method, slong cutoff)
{
    slong eb1 = FLINT_BITS * nlimbs1 - norm1;
    slong eb2 = FLINT_BITS * nlimbs2 - norm2;
    slong sbits, slimbs;
    int karatsuba = _flint_mpn_poly_mulmid_use_karatsuba(minlen, FLINT_MIN(norm1, norm2), method, cutoff);

    /* output bound: the number of terms; with Karatsuba also a sign bit,
       the growth in the recursion (up to two bits per level) and, for
       two's complement, the intermediate v - f0 g0 - f1 g1 */
    if (karatsuba)
        sbits = eb1 + eb2 + 2 * FLINT_BIT_COUNT(minlen) + 1 + (method == FLINT_MPN_POLY_MUL_SIGNED ? 2 : 0);
    else
        sbits = eb1 + eb2 + FLINT_BIT_COUNT(minlen) + (method == FLINT_MPN_POLY_MUL_SIGNMAG ? 1 : 0);

    slimbs = (sbits + FLINT_BITS - 1) / FLINT_BITS;
    slimbs = FLINT_MAX(slimbs, nlimbs1 + nlimbs2 - 1);

    /* If the recursion may need to extend the coefficients of either operand
       by a limb, the classical kernels need at least n1 + n2 + 1 output limbs. */
    if (karatsuba && _flint_mpn_poly_karatsuba_may_extend(FLINT_MIN(norm1, norm2), minlen, cutoff))
        slimbs = nlimbs1 + nlimbs2 + 1;

    FLINT_ASSERT(slimbs <= nlimbs1 + nlimbs2 + 1);

    return slimbs;
}

/* Chooses the representation and limb counts for computing coefficients
   [nlo, nhi) of the product of polynomials of lengths len1 and len2 with
   coefficients of at most |bits1| and |bits2| bits, a negative bound
   meaning that negative coefficients may be present. */
void _flint_mpn_poly_mulmid_params(mpn_poly_mul_params_t P, slong len1, slong bits1, slong len2, slong bits2, slong nlo, slong nhi, int squaring);

/* Coefficients [nlo, nhi) of the product (or the full product), choosing
   automatically between classical and Karatsuba-based multiplication,
   with the operands packed as described by method (FLINT_MPN_POLY_MUL_BIAS is
   treated as unsigned). The output limb count must be at least
   _flint_mpn_poly_mulmid_slimbs. */
void _flint_mpn_poly_mulmid(nn_ptr res, nn_srcptr f, slong flen, slong nlimbs1, slong norm1, nn_srcptr g, slong glen, slong nlimbs2, slong norm2, slong nlo, slong nhi, slong slimbs, int method);
void _flint_mpn_poly_mul(nn_ptr res, nn_srcptr f, slong flen, slong nlimbs1, slong norm1, nn_srcptr g, slong glen, slong nlimbs2, slong norm2, slong slimbs, int method);

void _flint_mpn_poly_mulmid_karatsuba(nn_ptr res, nn_srcptr f, slong flen, slong nlimbs1, slong norm1, nn_srcptr g, slong glen, slong nlimbs2, slong norm2, slong nlo, slong nhi, slong slimbs, slong cutoff, int sgn);

/* Instances of the classical algorithm with the dot products inlined in
   the coefficient loop (generated by dev/gen_mpn_dot_rev.py), for
   n1 <= 3. The sqrmid versions compute coefficients of f^2. The _short
   versions (for n1 = 4) use the assembly multiplication routines with
   register accumulation. */

/* Windowed middle product ***************************************************/

void flint_mpn_mulmid(mp_ptr z, mp_srcptr a, mp_size_t an, mp_srcptr b, mp_size_t bn, mp_size_t zlo, mp_size_t zhi);
void flint_mpn_mulmid_classical(mp_ptr z, mp_srcptr a, mp_size_t an, mp_srcptr b, mp_size_t bn, mp_size_t zlo, mp_size_t zhi);
void flint_mpn_mulmid_via_mul(mp_ptr z, mp_srcptr a, mp_size_t an, mp_srcptr b, mp_size_t bn, mp_size_t zlo, mp_size_t zhi);
void flint_mpn_mulmid_via_mullow_n(mp_ptr z, mp_srcptr a, mp_size_t an, mp_srcptr b, mp_size_t bn, mp_size_t zlo, mp_size_t zhi);
void flint_mpn_mulmid_via_mulhigh_n(mp_ptr z, mp_srcptr a, mp_size_t an, mp_srcptr b, mp_size_t bn, mp_size_t zlo, mp_size_t zhi);

#if FLINT_HAVE_FFT_SMALL
void flint_mpn_mulmid_fft_small(mp_ptr z, mp_srcptr a, mp_size_t an, mp_srcptr b, mp_size_t bn, mp_size_t zlo, mp_size_t zhi);
mp_limb_t _flint_mpn_mulhigh_n_fft_small(mp_ptr res, mp_srcptr u, mp_srcptr v, mp_size_t n);
mp_limb_t _flint_mpn_mullow_n_fft_small(mp_ptr res, mp_srcptr u, mp_srcptr v, mp_size_t n);
#endif

#if FLINT_HAVE_NATIVE_mpn_mulmid_n
void __gmpn_mulmid_n(mp_ptr, mp_srcptr, mp_srcptr, mp_size_t);

MPN_EXTRAS_INLINE
void flint_mpn_mulmid_n(mp_ptr rp, mp_srcptr ap, mp_srcptr bp, mp_size_t n)
{
    __gmpn_mulmid_n(rp, ap, bp, n);
}

void flint_mpn_mulmid_via_n_padded(mp_ptr z, mp_srcptr a, mp_size_t an, mp_srcptr b, mp_size_t bn, mp_size_t zlo, mp_size_t zhi);
#endif

FLINT_DLL extern const signed short flint_mpn_mulhigh_k_tab[FLINT_MPN_MULHIGH_K_TAB_SIZE];

mp_limb_t flint_mpn_mullow_basecase(mp_ptr res, mp_srcptr u, mp_srcptr v, mp_size_t n);
void _flint_mpn_mullow_n_mulders_recursive(mp_ptr rp, mp_srcptr np, mp_srcptr mp, mp_size_t n);
mp_limb_t _flint_mpn_mullow_n_mulders(mp_ptr res, mp_srcptr u, mp_srcptr v, mp_size_t n);
mp_limb_t _flint_mpn_mullow_n_mul(mp_ptr res, mp_srcptr u, mp_srcptr v, mp_size_t n);
mp_limb_t _flint_mpn_mullow_n(mp_ptr res, mp_srcptr u, mp_srcptr v, mp_size_t n);

mp_limb_t _flint_mpn_mulhigh_basecase(mp_ptr res, mp_srcptr u, mp_srcptr v, mp_size_t n);
void _flint_mpn_mulhigh_n_mulders_recursive(mp_ptr rp, mp_srcptr np, mp_srcptr mp, mp_size_t n);
mp_limb_t _flint_mpn_mulhigh_n_naive(mp_ptr rp, mp_srcptr up, mp_srcptr vp, mp_size_t n);
mp_limb_t _flint_mpn_mulhigh_n_recursive(mp_ptr r, mp_srcptr x, mp_srcptr y, mp_size_t n);
mp_limb_t _flint_mpn_mulhigh_n_mulders(mp_ptr res, mp_srcptr u, mp_srcptr v, mp_size_t n);
mp_limb_t _flint_mpn_mulhigh_n_mul(mp_ptr res, mp_srcptr u, mp_srcptr v, mp_size_t n);
mp_limb_t _flint_mpn_mulhigh_n(mp_ptr res, mp_srcptr u, mp_srcptr v, mp_size_t n);

#if FLINT_HAVE_ASSEMBLY_x86_64_adx
MPN_EXTRAS_INLINE
mp_limb_t _flint_mpn_mulhigh_n_basecase2(mp_ptr rp, mp_srcptr xp, mp_srcptr yp, mp_size_t n)
{
    if (n <= 22)
        return _flint_mpn_mulhigh_n_recursive(rp, xp, yp, n);
    else
        return _flint_mpn_mulhigh_basecase(rp, xp, yp, n);
}
#else
#define _flint_mpn_mulhigh_n_basecase2 _flint_mpn_mulhigh_basecase
#endif

MPN_EXTRAS_INLINE
mp_limb_t flint_mpn_mullow_n(mp_ptr rp, mp_srcptr xp, mp_srcptr yp, mp_size_t n)
{
    FLINT_ASSERT(n >= 1);
    FLINT_ASSERT(rp != xp);

    if (FLINT_HAVE_MULLOW_FUNC(n))
        return flint_mpn_mullow_func_tab[n](rp, xp, yp);
    else
        return _flint_mpn_mullow_n(rp, xp, yp, n);
}

MPN_EXTRAS_INLINE
mp_limb_t flint_mpn_mulhigh_n(mp_ptr rp, mp_srcptr xp, mp_srcptr yp, mp_size_t n)
{
    FLINT_ASSERT(n >= 1);

    if (FLINT_HAVE_MULHIGH_FUNC(n)) /* NOTE: Aliasing allowed here */
        return flint_mpn_mulhigh_func_tab[n](rp, xp, yp);
    else
        return _flint_mpn_mulhigh_n(rp, xp, yp, n);
}

/* We just want the high or low n limbs, but rp has 2n limbs available
   which can be used for scratch space or for doing a full multiply
   without temporary allocations. TODO: exploit this in the Mulders range
   by calling Mulders directly. */
MPN_EXTRAS_INLINE
void flint_mpn_mul_or_mullow_n(mp_ptr rp, mp_srcptr xp, mp_srcptr yp, mp_size_t n)
{
    FLINT_ASSERT(n >= 1);

    if (FLINT_HAVE_MULLOW_FUNC(n))
        rp[n] = flint_mpn_mullow_func_tab[n](rp, xp, yp);
#if FLINT_HAVE_FFT_SMALL
    else if (n < FLINT_MPN_MULHIGH_FFT_SMALL_CUTOFF)
        rp[n] = _flint_mpn_mullow_n(rp, xp, yp, n);
    else
        flint_mpn_mulmid_fft_small(rp, xp, n, yp, n, 0, n + 1);
#else
    else if (n < FLINT_MPN_MULHIGH_MUL_CUTOFF)
        rp[n] = _flint_mpn_mullow_n(rp, xp, yp, n);
    else
        flint_mpn_mul_n(rp, xp, yp, n);
#endif
}

MPN_EXTRAS_INLINE
void flint_mpn_mul_or_mulhigh_n(mp_ptr rp, mp_srcptr xp, mp_srcptr yp, mp_size_t n)
{
    FLINT_ASSERT(n >= 1);

    if (FLINT_HAVE_MULHIGH_FUNC(n))
        rp[n - 1] = flint_mpn_mulhigh_func_tab[n](rp + n, xp, yp);
#if FLINT_HAVE_FFT_SMALL
    else if (n < FLINT_MPN_MULHIGH_FFT_SMALL_CUTOFF)
        rp[n - 1] = _flint_mpn_mulhigh_n(rp + n, xp, yp, n);
    else
        flint_mpn_mulmid_fft_small(rp + n - 2, xp, n, yp, n, n - 2, 2 * n);
#else
    else if (n < FLINT_MPN_MULHIGH_MUL_CUTOFF)
        rp[n - 1] = _flint_mpn_mulhigh_n(rp + n, xp, yp, n);
    else
        flint_mpn_mul_n(rp, xp, yp, n);
#endif
}

#if FLINT_HAVE_ASSEMBLY_x86_64_adx
mp_limb_t _flint_mpn_sqrhigh_basecase_even(mp_ptr, mp_srcptr, mp_size_t);
mp_limb_t _flint_mpn_sqrhigh_basecase_odd(mp_ptr, mp_srcptr, mp_size_t);

MPN_EXTRAS_INLINE mp_limb_t _flint_mpn_sqrhigh_basecase(mp_ptr rp, mp_srcptr xp, mp_size_t n)
{
    FLINT_ASSERT(n >= 1);
    FLINT_ASSERT(rp != xp);

    if (n & 1)
        return _flint_mpn_sqrhigh_basecase_odd(rp, xp, n >> 1);
    else
        return _flint_mpn_sqrhigh_basecase_even(rp, xp, n >> 1);
}

#else
/* todo */
MPN_EXTRAS_INLINE mp_limb_t _flint_mpn_sqrhigh_basecase(mp_ptr res, mp_srcptr u, mp_size_t n)
{
    return _flint_mpn_mulhigh_basecase(res, u, u, n);
}
#endif

void _flint_mpn_sqrhigh_mulders_recursive(mp_ptr rp, mp_srcptr np, mp_size_t n);
mp_limb_t _flint_mpn_sqrhigh_mulders(mp_ptr res, mp_srcptr u, mp_size_t n);
mp_limb_t _flint_mpn_sqrhigh_sqr(mp_ptr res, mp_srcptr u, mp_size_t n);
mp_limb_t _flint_mpn_sqrhigh(mp_ptr res, mp_srcptr u, mp_size_t n);

MPN_EXTRAS_INLINE
mp_limb_t flint_mpn_sqrhigh_n(mp_ptr rp, mp_srcptr xp, mp_size_t n)
{
    FLINT_ASSERT(n >= 1);

    if (FLINT_HAVE_SQRHIGH_FUNC(n)) /* NOTE: Aliasing allowed here */
        return flint_mpn_sqrhigh_func_tab[n](rp, xp);
    else
        return _flint_mpn_sqrhigh(rp, xp, n);
}

mp_limb_pair_t _flint_mpn_mulhigh_n_normalised(mp_ptr rp, mp_srcptr xp, mp_srcptr yp, mp_size_t n);

MPN_EXTRAS_INLINE
mp_limb_pair_t flint_mpn_mulhigh_n_normalised(mp_ptr rp, mp_srcptr xp, mp_srcptr yp, mp_size_t n)
{
    FLINT_ASSERT(n >= 1);

    if (FLINT_HAVE_MULHIGH_NORMALISED_FUNC(n))
        return flint_mpn_mulhigh_normalised_func_tab[n](rp, xp, yp);
    else
        return _flint_mpn_mulhigh_n_normalised(rp, xp, yp, n);
}

mp_limb_pair_t _flint_mpn_sqrhigh_n_normalised(mp_ptr rp, mp_srcptr xp, mp_size_t n);

MPN_EXTRAS_INLINE
mp_limb_pair_t flint_mpn_sqrhigh_n_normalised(mp_ptr rp, mp_srcptr xp, mp_size_t n)
{
    FLINT_ASSERT(n >= 1);

    if (FLINT_HAVE_SQRHIGH_NORMALISED_FUNC(n))
        return flint_mpn_sqrhigh_normalised_func_tab[n](rp, xp);
    else
        return _flint_mpn_sqrhigh_n_normalised(rp, xp, n);
}

/* division ******************************************************************/

/* The division and square root cutoffs (FLINT_MPN_TDIV_QR_NEWTON_CUTOFF,
   FLINT_MPN_TDIV_QR_NEWTON_LONG_CUTOFF, FLINT_MPN_DIVEXACT_NEWTON_CUTOFF,
   FLINT_MPN_SQRTREM_NEWTON_CUTOFF, FLINT_MPN_DIV_DC_CUTOFF,
   FLINT_MPN_DIVAPPR_DC_CUTOFF, FLINT_MPN_DIVAPPROX_SHORT_CUTOFF,
   FLINT_MPN_TDIV_Q_DC_CUTOFF,
   FLINT_MPN_DIVAPPROX_NEWTON_CUTOFF,
   FLINT_MPN_INV_NEWTON_CUTOFF, FLINT_MPN_INV_NEWTON_LONG_CUTOFF,
   FLINT_MPN_INV_NEWTON_VERYLONG_CUTOFF,
   FLINT_MPN_DIVREM_1_HW_CUTOFF,
   FLINT_MPN_DIVREM_1_NORM_HW_CUTOFF, FLINT_MPN_DIV_2_HW_CUTOFF,
   FLINT_MPN_DIV_SMALL_HW_QN_CUTOFF, FLINT_MPN_DIV_2_GMP_CUTOFF,
   FLINT_MPN_DIVEXACT_UNBALANCED_CUTOFF, FLINT_MPN_DC_BDIV_QR_CUTOFF,
   FLINT_MPN_DC_BDIV_Q_CUTOFF) are defined per architecture in
   flint-mparam.h and measured by src/mpn_extras/tune/tune-div.c. The
   divide and conquer cutoffs must be at least 6.

   Newton division is used for Bn >= FLINT_MPN_TDIV_QR_NEWTON_CUTOFF with a
   quotient at least as long, and already for Bn >=
   FLINT_MPN_TDIV_QR_NEWTON_LONG_CUTOFF when the quotient has >= 2 Bn limbs. */

/* Where hardware division is fast (FLINT_PREINVERT_LIMB_USE_NATIVE),
   one-limb divisors use a chain of hardware divisions for dividends shorter
   than FLINT_MPN_DIVREM_1_HW_CUTOFF limbs, respectively
   FLINT_MPN_DIVREM_1_NORM_HW_CUTOFF limbs for normalized divisors (for
   which GMP's mpn_divrem_1 needs no shifts), and mpn_divrem_1 otherwise */
#define FLINT_MPN_DIVREM_1_USE_HW(an, d) \
    ((an) < (((d) >> (FLINT_BITS - 1)) ? FLINT_MPN_DIVREM_1_NORM_HW_CUTOFF \
                                       : FLINT_MPN_DIVREM_1_HW_CUTOFF))

/* block division with a shared Newton inverse (_flint_mpn_tdiv_qr_unbalanced)
   from these divisor lengths when an >= 4 bn, respectively an >= 3 bn */
#ifndef FLINT_MPN_TDIV_QR_UNBALANCED4_CUTOFF   /* an >= 4 bn */
#define FLINT_MPN_TDIV_QR_UNBALANCED4_CUTOFF 64
#endif
#ifndef FLINT_MPN_TDIV_QR_UNBALANCED3_CUTOFF   /* an >= 3 bn */
#define FLINT_MPN_TDIV_QR_UNBALANCED3_CUTOFF 512
#endif

/* Shapes handled by the register-based division for short divisors
   (_flint_mpn_tdiv_qr_small, div_qr.c); for divisors of more than three
   limbs it is used for short dividends, where it beats the schoolbook
   division with function calls. Without the remainder, the schoolbook
   division with a truncated divisor (_flint_mpn_div_basecase_preinv1) wins for longer
   dividends, and for seven-limb divisors unless the limb inversion is
   fast. */
#if FLINT_PREINVERT_LIMB_USE_NATIVE
# define FLINT_MPN_DIV_SMALL_SHAPE(an, bn, want_r) \
    ((bn) <= 3 || ((bn) <= FLINT_MPN_DIV_SMALL_BN && \
        ((want_r) ? ((an) <= 3 * (bn)) : ((an) <= (bn) + 2))))
#else
# define FLINT_MPN_DIV_SMALL_SHAPE(an, bn, want_r) \
    ((bn) <= 3 || ((bn) <= FLINT_MPN_DIV_SMALL_BN && \
        ((want_r) ? ((an) <= 3 * (bn)) : ((bn) <= 6 && (an) <= (bn) + 2))))
#endif

#if FLINT_HAVE_NATIVE_mpn_modexact_1_odd
# define mpn_modexact_1_odd __gmpn_modexact_1_odd
mp_limb_t mpn_modexact_1_odd(mp_srcptr, mp_size_t, mp_limb_t);
#endif

#if FLINT_HAVE_NATIVE_mpn_invert_limb
# define mpn_invert_limb __gmpn_invert_limb
mp_limb_t mpn_invert_limb(mp_limb_t);
#endif

void flint_mpn_preinvn(mp_ptr dinv, mp_srcptr d, mp_size_t n);

/* Preinverted division (div_qr.c), as GMP's mpn_sbpi1_* and mpn_dcpi1_*
   functions with divide and conquer steps using FLINT's multiplication.
   Cutoffs (divisor limbs) are defined per architecture in flint-mparam.h. */


/* floor((B^2 - 1) / d) - B for a normalized limb d, inline: a hardware
   division where that is fast (FLINT_PREINVERT_LIMB_USE_NATIVE), otherwise
   the table-based method of n_preinvert_limb_prenorm */
#if FLINT_BITS == 64
FLINT_DLL extern const unsigned short flint_invert_limb_tab[256];
#endif

#if FLINT_PREINVERT_LIMB_USE_NATIVE
# define FLINT_MPN_INVERT_LIMB(v, d) \
    do { mp_limb_t __r; udiv_qrnnd((v), __r, ~(d), ~UWORD(0), (d)); (void) __r; } while (0)
#elif FLINT_HAVE_NATIVE_mpn_invert_limb
/* GMP's assembly table-based inversion */
mp_limb_t __gmpn_invert_limb(mp_limb_t);
# define FLINT_MPN_INVERT_LIMB(v, d) do { (v) = __gmpn_invert_limb(d); } while (0)
#elif FLINT_BITS == 64
# define FLINT_MPN_INVERT_LIMB(dinv, d) \
    do { \
        mp_limb_t __v0, __v2, __d40, __e, __m0, __d = (d); \
        __d40 = (__d >> 24) + 1; \
        __v0 = flint_invert_limb_tab[(__d >> 55) & 0xFF]; \
        __v0 = (__v0 << 11) - ((__v0 * __v0 * __d40) >> 40) - 1; \
        __v2 = ((__v0 * ((UWORD(1) << 60) - __v0 * __d40)) >> 47); \
        __v2 += (__v0 << 13); \
        __e = -__v2 * (__d >> 1); \
        __m0 = -(__d & UWORD(1)); \
        __e -= ((__v2 - (__v2 >> 1)) & __m0); \
        umul_ppmm(__v0, __d40, __v2, __e); \
        __v2 = (__v2 << 31) + (__v0 >> 1); \
        umul_ppmm(__v0, __d40, __v2, __d); \
        add_ssaaaa(__v0, __d40, __v0, __d40, UWORD(0), __d); \
        (dinv) = __v2 - (__v0 + __d); \
    } while (0)
#else
# define FLINT_MPN_INVERT_LIMB(v, d) do { (v) = n_preinvert_limb_prenorm(d); } while (0)
#endif

/* the 3/2 inverse floor((B^3 - 1) / (d1 B + d0)) - B for d1 >= B/2 (GMP's
   invert_pi1), used by the preinv1 division functions */
MPN_EXTRAS_INLINE mp_limb_t
flint_mpn_preinv1(mp_limb_t d1, mp_limb_t d0)
{
    mp_limb_t v, p, t1, t0, mask;

    FLINT_ASSERT(d1 >> (FLINT_BITS - 1));

    FLINT_MPN_INVERT_LIMB(v, d1);
    p = d1 * v + d0;
    if (p < d0)
    {
        v--;
        mask = -(mp_limb_t) (p >= d1);
        p -= d1;
        v += mask;
        p -= mask & d1;
    }
    umul_ppmm(t1, t0, d0, v);
    p += t1;
    if (p < t1)
    {
        v--;
        if (p >= d1 && (p > d1 || t0 >= d0))
            v--;
    }
    return v;
}

/* The same 3/2 division without an inverse, by one hardware 2/1 division
   of (n2, n1) by d1 and at most two corrections (a step of Knuth's
   algorithm D); only sensible where hardware division is fast
   (FLINT_PREINVERT_LIMB_USE_NATIVE). If n2 = d1 (so n1 < d0), the
   quotient is B - 1 or B - 2 and the remainder is (n1, n0) - (d0, 0)
   + (d1, d0) (mod B^2), plus (d1, d0) again if that is negative. The
   signs are read off the two-limb values: a candidate remainder y lies
   in [-d, d) and, before the last correction, above d - B^2, so y is
   nonnegative iff y mod B^2 < d. */
#define FLINT_MPN_UDIV_QR_3BY2_HW(q, r1, r0, n2, n1, n0, d1, d0) \
    do { \
        mp_limb_t __q, __r, __p1, __p0, __x1, __x0, __n0 = (n0); \
        if (FLINT_UNLIKELY((n2) == (d1))) \
        { \
            __q = ~UWORD(0); \
            sub_ddmmss(__x1, __x0, (n1), __n0, (d0), 0); \
            add_ssaaaa(__x1, __x0, __x1, __x0, (d1), (d0)); \
            if (__x1 > (d1) || (__x1 == (d1) && __x0 >= (d0))) \
            { \
                __q--; \
                add_ssaaaa(__x1, __x0, __x1, __x0, (d1), (d0)); \
            } \
        } \
        else \
        { \
            udiv_qrnnd(__q, __r, (n2), (n1), (d1)); \
            umul_ppmm(__p1, __p0, __q, (d0)); \
            sub_ddmmss(__x1, __x0, __r, __n0, __p1, __p0); \
            if (__r < __p1 || (__r == __p1 && __n0 < __p0)) \
            { \
                /* negative: add d once or twice */ \
                __q--; \
                add_ssaaaa(__x1, __x0, __x1, __x0, (d1), (d0)); \
                if (__x1 > (d1) || (__x1 == (d1) && __x0 >= (d0))) \
                { \
                    __q--; \
                    add_ssaaaa(__x1, __x0, __x1, __x0, (d1), (d0)); \
                } \
            } \
        } \
        (q) = __q; \
        (r1) = __x1; \
        (r0) = __x0; \
    } while (0)

/* Moller-Granlund 3/2 division: (n2, n1, n0) = q (d1, d0) + (r1, r0),
   requires (n2, n1) < (d1, d0), d1 normalized and dinv =
   flint_mpn_preinv1(d1, d0) */
#define FLINT_MPN_UDIV_QR_3BY2(q, r1, r0, n2, n1, n0, d1, d0, dinv) \
    do { \
        mp_limb_t __u3b2_q0, __u3b2_t1, __u3b2_t0, __u3b2_mask; \
        umul_ppmm((q), __u3b2_q0, (n2), (dinv)); \
        add_ssaaaa((q), __u3b2_q0, (q), __u3b2_q0, (n2), (n1)); \
        (r1) = (n1) - (d1) * (q); \
        sub_ddmmss((r1), (r0), (r1), (n0), (d1), (d0)); \
        umul_ppmm(__u3b2_t1, __u3b2_t0, (d0), (q)); \
        sub_ddmmss((r1), (r0), (r1), (r0), __u3b2_t1, __u3b2_t0); \
        (q)++; \
        __u3b2_mask = -(mp_limb_t) ((r1) >= __u3b2_q0); \
        (q) += __u3b2_mask; \
        add_ssaaaa((r1), (r0), (r1), (r0), __u3b2_mask & (d1), __u3b2_mask & (d0)); \
        if (FLINT_UNLIKELY((r1) >= (d1))) \
        { \
            if ((r1) > (d1) || (r0) >= (d0)) \
            { \
                (q)++; \
                sub_ddmmss((r1), (r0), (r1), (r0), (d1), (d0)); \
            } \
        } \
    } while (0)

/* Division with divisors of at most FLINT_MPN_DIV_SMALL_BN limbs, keeping
   the divisor and the partial remainder in registers (div_qr.c).
   Writes the an - bn + 1 quotient limbs and, if rp != NULL, the bn
   remainder limbs; no normalization of b is needed. */
#define FLINT_MPN_DIV_SMALL_BN 7
void _flint_mpn_tdiv_qr_small(mp_ptr qp, mp_ptr rp, mp_srcptr ap, mp_size_t an, mp_srcptr bp, mp_size_t bn);
mp_limb_t _flint_mpn_divrem_basecase_preinv1(mp_ptr qp, mp_ptr np, mp_size_t nn, mp_srcptr dp, mp_size_t dn, mp_limb_t dinv);
mp_limb_t _flint_mpn_divapprox_basecase_preinv1(mp_ptr qp, mp_ptr np, mp_size_t nn, mp_srcptr dp, mp_size_t dn, mp_limb_t dinv);
mp_limb_t _flint_mpn_div_basecase_preinv1(mp_ptr qp, mp_ptr np, mp_size_t nn, mp_srcptr dp, mp_size_t dn, mp_limb_t dinv);
mp_limb_t _flint_mpn_divrem_n_divconquer_preinv1(mp_ptr qp, mp_ptr np, mp_srcptr dp, mp_size_t n, mp_limb_t dinv, mp_ptr tp);
mp_limb_t _flint_mpn_divapprox_n_divconquer_preinv1(mp_ptr qp, mp_ptr np, mp_srcptr dp, mp_size_t n, mp_limb_t dinv, mp_ptr tp);
mp_limb_t _flint_mpn_divrem_preinv1(mp_ptr qp, mp_ptr np, mp_size_t nn, mp_srcptr dp, mp_size_t dn, mp_limb_t dinv, mp_ptr tp);
mp_limb_t _flint_mpn_divapprox_preinv1(mp_ptr qp, mp_ptr np, mp_size_t nn, mp_srcptr dp, mp_size_t dn, mp_limb_t dinv, mp_ptr tp);
void _flint_mpn_tdiv_qr_divconquer(mp_ptr Q, mp_ptr R, mp_srcptr A, mp_size_t An, mp_srcptr B, mp_size_t Bn);
void _flint_mpn_tdiv_q_divconquer(mp_ptr Q, mp_srcptr A, mp_size_t An, mp_srcptr B, mp_size_t Bn);
void flint_mpn_divapprox(mp_ptr Q, mp_srcptr A, mp_size_t An, mp_srcptr B, mp_size_t Bn);
void flint_mpn_divapprox_fraction(mp_ptr Q, mp_srcptr A, mp_size_t An, mp_srcptr B, mp_size_t Bn, mp_size_t f);
void flint_mpn_invapprox(mp_ptr q, mp_srcptr x, mp_size_t xn, mp_size_t n);
mp_ptr _flint_mpn_invapprox_buf(mp_ptr U, mp_srcptr x, mp_size_t xn, mp_size_t n);

#if defined(mpn_modexact_1_odd)
MPN_EXTRAS_INLINE
int flint_mpn_divisible_1_odd(mp_srcptr x, mp_size_t xsize, mp_limb_t d)
{
    return mpn_modexact_1_odd(x, xsize, d) == 0;
}
#else
# include "gmpcompat.h"
MPN_EXTRAS_INLINE
int flint_mpn_divisible_1_odd(mp_srcptr x, mp_size_t xsize, mp_limb_t d)
{
    __mpz_struct s;
    s._mp_size = xsize;
    s._mp_d = (mp_ptr) x;
    return flint_mpz_divisible_ui_p(&s, d);
}
#endif

/* Floating-point quotients, square roots and reciprocal square roots
   with a guard limb (divhigh.c, sqrthigh.c), the kernels shared by arf,
   arb and nfloat. The operands are normalised fractions A = {a, an} /
   B^an, Y = {b, bn} / B^bn in [1/2, 1) (top bit set); t is the parity of
   the exponent of x = A 2^e. Each function writes n + 1 limbs, the lowest
   a guard limb, which lie in [B^(n+1) / 2, B^(n+1)) and approximate

     divhigh:   2^-s (A / Y) B^(n+1), returning s = [A >= Y] (so that the
                quotient is A / Y = 2^s Q / B^(n+1); the shift is taken
                from the operands truncated to n + 2 limbs)
     invhigh:   the same for A = 1/2, i.e. 1/Y = 2^(s+1) Q / B^(n+1)
     sqrthigh:  S B^(n+1) with S = sqrt(A / 2^t) in [1/2, 1), so that
                sqrt(x) = S 2^((e + t) / 2)
     rsqrthigh: M B^(n+1) with M = (2^(2-t) A)^(-1/2) in (1/2, 1], so that
                1/sqrt(x) = M 2^((1 - t) - (e - t) / 2) (clamped to
                B^(n+1) - 1 when M = 1, i.e. t = 1 and A = 1/2)

   to within the absolute error bounds below (in units of the guard limb,
   in either direction). The _exact variants compute the floor of the
   same quantity from the full operands (the shift s of divhigh_exact
   then from the full comparison) and return whether it is not an
   integer, i.e. whether the floating-point result is inexact; they are
   the fallbacks of directed rounding when the guard limb is within the
   error bound of a rounding boundary. sqrthigh_exact_half returns more
   precisely 0 (exact), 1 (the value within the first half unit above
   the floor), 2 (exactly half a unit above: a tie, possible only with
   dropped limbs of a) or 3 (above that), which decides every rounding
   mode at n + 1 limbs (it forms the remainder of the integer root,
   which costs for long inputs); sqrthigh_exact_rem also writes that
   remainder X - F^2 (n + 2 limbs, zero-padded) for X the radicand of
   the n + 1 limbs. rsqrthigh_exact requires M < 1. */
#define FLINT_MPN_DIVHIGH_GUARD_ERR_BOUND 16
#define FLINT_MPN_SQRTHIGH_GUARD_ERR_BOUND 32
#define FLINT_MPN_RSQRTHIGH_GUARD_ERR_BOUND 256
ulong flint_mpn_divhigh(nn_ptr q, nn_srcptr a, slong an, nn_srcptr b, slong bn, slong n);
ulong flint_mpn_invhigh(nn_ptr q, nn_srcptr b, slong bn, slong n);
int flint_mpn_divhigh_exact(nn_ptr q, ulong * s, nn_srcptr a, slong an, nn_srcptr b, slong bn, slong n);
void flint_mpn_sqrthigh(nn_ptr s, nn_srcptr a, slong an, int t, slong n);
int flint_mpn_sqrthigh_exact(nn_ptr s, nn_srcptr a, slong an, int t, slong n);
int flint_mpn_sqrthigh_exact_half(nn_ptr s, nn_srcptr a, slong an, int t, slong n);
int flint_mpn_sqrthigh_exact_rem(nn_ptr s, nn_ptr r, nn_srcptr a, slong an, int t, slong n);
void flint_mpn_rsqrthigh(nn_ptr y, nn_srcptr a, slong an, int t, slong n);
int flint_mpn_rsqrthigh_exact(nn_ptr y, nn_srcptr a, slong an, int t, slong n);
/* the fixed-point Newton iteration of flint_mpn_rsqrthigh (N >= 2 limbs,
   error below 196 units of the lowest limb at N = 4, 1.03 otherwise, 8 at
   N = 2), which flint_mpn_rsqrthigh uses for n + 1 <=
   FLINT_MPN_RSQRTHIGH_MP_REAL_CUTOFF result limbs and the mp_real
   iteration beyond; exported for tuning the cutoff, and for callers in
   that range (the kernels of arf) to skip the dispatch */
#define FLINT_MPN_RSQRTHIGH_MP_REAL_CUTOFF 96
void _flint_mpn_rsqrthigh_newton(nn_ptr Y, slong N, nn_srcptr a, slong an, ulong t);

/* historical name of the quotient-only division */
#define mpn_tdiv_q(qp, np, nn, dp, dn) flint_mpn_tdiv_q(qp, np, nn, dp, dn)

int flint_mpn_divides(mp_ptr q, mp_srcptr ap, mp_size_t an, mp_srcptr bp, mp_size_t bn, mp_ptr scr);

void flint_mpn_mod_preinvn(mp_ptr r, mp_srcptr a, mp_size_t m, mp_srcptr d, mp_size_t n, mp_srcptr dinv);

mp_limb_t flint_mpn_divrem_preinv1(mp_ptr q, mp_ptr a, mp_size_t m, mp_srcptr b, mp_size_t n, mp_limb_t dinv);
mp_limb_t flint_mpn_divrem_preinvn(mp_ptr q, mp_ptr r, mp_srcptr a, mp_size_t m, mp_srcptr d, mp_size_t n, mp_srcptr dinv);

mp_limb_t flint_mpn_divrem_1_preinv(mp_ptr qp, mp_srcptr up, mp_size_t n, mp_limb_t d, mp_limb_t dinv, unsigned int norm);
mp_limb_t flint_mpn_divrem_2_1_preinv_norm(mp_ptr qp, mp_srcptr up, mp_limb_t d, mp_limb_t dinv);
mp_limb_t flint_mpn_divrem_2_1_preinv_unnorm(mp_ptr qp, mp_srcptr up, mp_limb_t d, mp_limb_t dinv, unsigned int norm);
mp_limb_t flint_mpn_divrem_3_1_preinv_norm(mp_ptr qp, mp_srcptr up, mp_limb_t d, mp_limb_t dinv);
mp_limb_t flint_mpn_divrem_3_1_preinv_unnorm(mp_ptr qp, mp_srcptr up, mp_limb_t d, mp_limb_t dinv, unsigned int norm);

/* high product with known low limbs *****************************************/

void _flint_mpn_mulhigh_known_low(mp_ptr out, mp_srcptr x, mp_size_t xn, mp_srcptr y, mp_size_t yn, mp_srcptr kl, mp_size_t kl_len, mp_size_t klo, mp_size_t khi, mp_ptr scratch);

/* Hensel (2-adic) division and square root **********************************/

void flint_mpn_binv(mp_ptr res, mp_srcptr x, mp_size_t xn, mp_size_t n);

void flint_mpn_bdiv_qr_1(mp_ptr q, mp_ptr r, mp_srcptr a, mp_size_t an, mp_limb_t b, mp_size_t n);
void flint_mpn_bdiv_qr_classical(mp_ptr q, mp_ptr r, mp_srcptr a, mp_size_t an, mp_srcptr b, mp_size_t bn, mp_size_t n);
void _flint_mpn_bdiv_qr_classical_preinv(mp_ptr q, mp_ptr r, mp_srcptr a, mp_size_t an, mp_srcptr b, mp_size_t bn, mp_srcptr binv, mp_size_t n);
void flint_mpn_bdiv_qr_karp_markstein(mp_ptr q, mp_ptr r, mp_srcptr a, mp_size_t an, mp_srcptr b, mp_size_t bn, mp_size_t n);
void flint_mpn_bdiv_qr(mp_ptr q, mp_ptr r, mp_srcptr a, mp_size_t an, mp_srcptr b, mp_size_t bn, mp_size_t n);

MPN_EXTRAS_INLINE void
flint_mpn_bdiv_q(mp_ptr q, mp_srcptr a, mp_size_t an, mp_srcptr b, mp_size_t bn, mp_size_t n)
{
    flint_mpn_bdiv_qr(q, NULL, a, an, b, bn, n);
}

int flint_mpn_brsqrt(mp_ptr res, mp_srcptr x, mp_size_t xn, mp_size_t n);
int flint_mpn_bsqrt(mp_ptr res, mp_srcptr x, mp_size_t xn, mp_size_t n);

/* Euclidean division ********************************************************/

void flint_mpn_inv(mp_ptr q, mp_srcptr x, mp_size_t xn, mp_size_t n);
void _flint_mpn_inv_basecase(mp_ptr q, mp_srcptr x, mp_size_t xn, mp_size_t n);

#if FLINT_HAVE_NATIVE_mpn_divexact
# define mpn_divexact __gmpn_divexact
void mpn_divexact(mp_ptr, mp_srcptr, mp_size_t, mp_srcptr, mp_size_t);
#endif

#if FLINT_HAVE_NATIVE_mpn_mod_34lsub1
# define mpn_mod_34lsub1 __gmpn_mod_34lsub1
mp_limb_t mpn_mod_34lsub1(mp_srcptr, mp_size_t);
#endif

int _flint_mpn_divisible(mp_srcptr a, mp_size_t an, mp_srcptr b, mp_size_t bn);
int _flint_mpn_divisible_bdiv(mp_srcptr a, mp_size_t an, mp_srcptr b, mp_size_t bn, unsigned int v);
int _flint_mpn_divisible_small(mp_srcptr a, mp_size_t an, mp_srcptr b, mp_size_t bn, unsigned int v);

MPN_EXTRAS_INLINE int
flint_mpn_divisible(mp_srcptr a, mp_size_t an, mp_srcptr b, mp_size_t bn)
{
    if (bn == 1 && an == 1)
        return a[0] % b[0] == 0;
    return _flint_mpn_divisible(a, an, b, bn);
}

/* powering */
mp_size_t flint_mpn_pow_bound_limbs(mp_srcptr x, mp_size_t xn, ulong e);
mp_size_t flint_mpn_pow(mp_ptr res, mp_srcptr x, mp_size_t xn, ulong e);

#if FLINT_BITS == 64
/* a value congruent to a modulo 2^48 - 1, below 2^50 (like GMP's
   mpn_mod_34lsub1, which is used for short inputs; AVX2 kernel otherwise) */
mp_limb_t flint_mpn_mod_2exp48m1(mp_srcptr a, mp_size_t n);
#endif

void _flint_mpn_tdiv_qr_preinv(mp_ptr q, mp_ptr r, mp_srcptr a, mp_size_t an, mp_srcptr b, mp_size_t bn, mp_srcptr binv, mp_size_t binvn);
void _flint_mpn_tdiv_qr_newton(mp_ptr q, mp_ptr r, mp_srcptr a, mp_size_t an, mp_srcptr b, mp_size_t bn);
void _flint_mpn_tdiv_qr_unbalanced(mp_ptr q, mp_ptr r, mp_srcptr a, mp_size_t an, mp_srcptr b, mp_size_t bn);
void _flint_mpn_tdiv_qr_preinvn(mp_ptr q, mp_ptr r, mp_srcptr a, mp_size_t an, mp_srcptr b, mp_size_t bn);
void _flint_mpn_tdiv_qr(mp_ptr q, mp_ptr r, mp_srcptr a, mp_size_t an, mp_srcptr b, mp_size_t bn);

MPN_EXTRAS_INLINE void
flint_mpn_tdiv_qr(mp_ptr q, mp_ptr r, mp_srcptr a, mp_size_t an, mp_srcptr b, mp_size_t bn)
{
    _flint_mpn_tdiv_qr(q, r, a, an, b, bn);
}

MPN_EXTRAS_INLINE void
flint_mpn_tdiv_q(mp_ptr q, mp_srcptr a, mp_size_t an, mp_srcptr b, mp_size_t bn)
{
    _flint_mpn_tdiv_qr(q, NULL, a, an, b, bn);
}

MPN_EXTRAS_INLINE void
flint_mpn_tdiv_r(mp_ptr r, mp_srcptr a, mp_size_t an, mp_srcptr b, mp_size_t bn)
{
    mp_ptr q;
    TMP_INIT;
    TMP_START;
    q = (mp_ptr) TMP_ALLOC((an - bn + 1) * sizeof(mp_limb_t));
    flint_mpn_tdiv_qr(q, r, a, an, b, bn);
    TMP_END;
}

void flint_mpn_cdiv_qr(mp_ptr q, mp_ptr r, mp_srcptr a, mp_size_t an, mp_srcptr b, mp_size_t bn);
void flint_mpn_cdiv_q(mp_ptr q, mp_srcptr a, mp_size_t an, mp_srcptr b, mp_size_t bn);
void flint_mpn_cdiv_r(mp_ptr r, mp_srcptr a, mp_size_t an, mp_srcptr b, mp_size_t bn);

int flint_mpn_ndiv_qr(mp_ptr q, mp_ptr r, mp_srcptr a, mp_size_t an, mp_srcptr b, mp_size_t bn);
void flint_mpn_ndiv_q(mp_ptr q, mp_srcptr a, mp_size_t an, mp_srcptr b, mp_size_t bn);
int flint_mpn_ndiv_r(mp_ptr r, mp_srcptr a, mp_size_t an, mp_srcptr b, mp_size_t bn);

int flint_mpn_div(mp_ptr q, mp_srcptr a, mp_size_t an, mp_srcptr b, mp_size_t bn);

void _flint_mpn_divexact_hensel(mp_ptr q, mp_srcptr a, mp_size_t an, mp_srcptr b, mp_size_t bn);
void _flint_mpn_divexact(mp_ptr q, mp_srcptr a, mp_size_t an, mp_srcptr b, mp_size_t bn);

/* largest truncated divisor (min(bn, qn) limbs) handled by the
   register-based Hensel division */
#define FLINT_MPN_DIVEXACT_SMALL_BN 7

MPN_EXTRAS_INLINE void
flint_mpn_divexact(mp_ptr q, mp_srcptr a, mp_size_t an, mp_srcptr b, mp_size_t bn)
{
    if (bn == 1)
        mpn_divexact_1(q, a, an, b[0]);
    else
        _flint_mpn_divexact(q, a, an, b, bn);
}

/* exact division by a fixed divisor with a precomputed 2-adic inverse */
typedef struct
{
    mp_ptr b;           /* odd part b' of the divisor, bn limbs */
    mp_ptr binv;        /* b'^(-1) mod B^binvn */
    mp_size_t binvn;    /* limbs of binv: bn + 1, or fewer with init_prec */
    mp_size_t bn;
    mp_size_t bn_orig;  /* limbs of the original divisor */
    mp_size_t k;        /* zero low limbs stripped */
    unsigned int v;     /* remaining 2-adic valuation */
}
flint_mpn_divexact_preinv_struct;

typedef flint_mpn_divexact_preinv_struct flint_mpn_divexact_preinv_t[1];

void flint_mpn_divexact_preinv_init(flint_mpn_divexact_preinv_t pre, mp_srcptr b, mp_size_t bn);
void flint_mpn_divexact_preinv_init_prec(flint_mpn_divexact_preinv_t pre, mp_srcptr b, mp_size_t bn, mp_size_t qn);
void flint_mpn_divexact_preinv_clear(flint_mpn_divexact_preinv_t pre);
void flint_mpn_divexact_preinv(mp_ptr q, mp_srcptr a, mp_size_t an, const flint_mpn_divexact_preinv_t pre);



/* mpz-like interface ********************************************************/

void flint_mpz_tdiv_qr(mpz_ptr q, mpz_ptr r, mpz_srcptr a, mpz_srcptr b);
void flint_mpz_tdiv_q(mpz_ptr q, mpz_srcptr a, mpz_srcptr b);
void flint_mpz_tdiv_r(mpz_ptr r, mpz_srcptr a, mpz_srcptr b);
void flint_mpz_fdiv_qr(mpz_ptr q, mpz_ptr r, mpz_srcptr a, mpz_srcptr b);
void flint_mpz_fdiv_q(mpz_ptr q, mpz_srcptr a, mpz_srcptr b);
void flint_mpz_fdiv_r(mpz_ptr r, mpz_srcptr a, mpz_srcptr b);
void flint_mpz_cdiv_qr(mpz_ptr q, mpz_ptr r, mpz_srcptr a, mpz_srcptr b);
void flint_mpz_cdiv_q(mpz_ptr q, mpz_srcptr a, mpz_srcptr b);
void flint_mpz_cdiv_r(mpz_ptr r, mpz_srcptr a, mpz_srcptr b);
void flint_mpz_mod(mpz_ptr r, mpz_srcptr a, mpz_srcptr b);
void flint_mpz_divexact(mpz_ptr q, mpz_srcptr a, mpz_srcptr b);
void flint_mpz_sqrtrem(mpz_ptr s, mpz_ptr r, mpz_srcptr a);
void flint_mpz_sqrt(mpz_ptr s, mpz_srcptr a);
void flint_mpz_gcd(mpz_ptr g, mpz_srcptr a, mpz_srcptr b);
void flint_mpz_gcdext(mpz_ptr g, mpz_ptr s, mpz_ptr t, mpz_srcptr a, mpz_srcptr b);
int flint_mpz_invert(mpz_ptr r, mpz_srcptr x, mpz_srcptr n);

mp_size_t _flint_mpn_sqrtrem(mp_ptr s, mp_ptr r, mp_srcptr a, mp_size_t an);

/* inputs of up to this many limbs have dedicated code in _flint_mpn_sqrtrem
   (hardware square root and a specialized divide and conquer step, up to
   three times faster than GMP), which needs sn + 1 limbs of remainder space */
#if FLINT_BITS == 64
# define FLINT_MPN_SQRTREM_SMALL 4
#else
# define FLINT_MPN_SQRTREM_SMALL 2
#endif

/* whether GMP's mpn_sqrtrem is used (on 64-bit machines, FLINT's divide and
   conquer code is used below the Newton cutoff instead) */
#if FLINT_BITS == 64
# define FLINT_MPN_SQRTREM_USE_GMP(an) 0
#else
# define FLINT_MPN_SQRTREM_USE_GMP(an) \
    ((an) > FLINT_MPN_SQRTREM_SMALL && (an) < FLINT_MPN_SQRTREM_NEWTON_CUTOFF)
#endif

/* square root ***************************************************************/


void _flint_mpn_sqrtrem_newton(mp_ptr s, mp_ptr r, mp_srcptr a, mp_size_t an);
void _flint_mpn_sqrtrem_gmp(mp_ptr s, mp_ptr r, mp_srcptr a, mp_size_t an);
mp_size_t _flint_mpn_sqrtrem_divconquer(mp_ptr s, mp_ptr r, mp_srcptr a, mp_size_t an);
mp_size_t _flint_mpn_sqrtrem(mp_ptr s, mp_ptr r, mp_srcptr a, mp_size_t an);

MPN_EXTRAS_INLINE mp_size_t
flint_mpn_sqrtrem(mp_ptr s, mp_ptr r, mp_srcptr a, mp_size_t an)
{
    /* with no remainder wanted, GMP's routine is called directly where it
       would be used anyway */
    if (r == NULL && FLINT_MPN_SQRTREM_USE_GMP(an))
        return mpn_sqrtrem(s, NULL, a, an) != 0;
    return _flint_mpn_sqrtrem(s, r, a, an);
}
int _flint_mpn_sqrt(mp_ptr s, mp_srcptr a, mp_size_t an);
int _flint_mpn_is_square(mp_srcptr a, mp_size_t an);

/* bit i set iff i is a square modulo 256 */
FLINT_DLL extern const unsigned char flint_mpn_sq256_tab[32];
#define FLINT_MPN_SQUARE_MOD256(x) ((flint_mpn_sq256_tab[((x) & 255) >> 3] >> ((x) & 7)) & 1)

MPN_EXTRAS_INLINE int
flint_mpn_sqrt(mp_ptr s, mp_srcptr a, mp_size_t an)
{
    if (!FLINT_MPN_SQUARE_MOD256(a[0]))
        return 0;
    return _flint_mpn_sqrt(s, a, an);
}

MPN_EXTRAS_INLINE int
flint_mpn_is_square(mp_srcptr a, mp_size_t an)
{
    if (!FLINT_MPN_SQUARE_MOD256(a[0]))
        return 0;
    return _flint_mpn_is_square(a, an);
}

/* composed arithmetic *******************************************************/

mp_size_t flint_mpn_fmms1(mp_ptr y, mp_limb_t a1, mp_srcptr x1, mp_limb_t a2, mp_srcptr x2, mp_size_t n);

/* debug *********************************************************************/

void flint_mpn_debug(mp_srcptr x, mp_size_t xsize);

/* factorisation *************************************************************/

mp_size_t flint_mpn_remove_2exp(mp_ptr x, mp_size_t xsize, flint_bitcnt_t * bits);

mp_size_t flint_mpn_remove_power_ascending(mp_ptr x, mp_size_t xsize, mp_ptr p, mp_size_t psize, ulong * exp);

int flint_mpn_factor_trial(mp_srcptr x, mp_size_t xsize, slong start, slong stop);

int flint_mpn_factor_trial_tree(slong * factors, mp_srcptr x, mp_size_t xsize, slong num_primes);

/* greatest common divisor ***************************************************/

/* gcd and extended gcd of nonzero normalised values, in any order; the
   inputs are not modified */
mp_size_t flint_mpn_gcd(mp_ptr gp, mp_srcptr ap, mp_size_t an, mp_srcptr bp, mp_size_t bn);
mp_size_t flint_mpn_gcdext(mp_ptr gp, mp_ptr sp, mp_size_t * sn, mp_srcptr ap, mp_size_t an, mp_srcptr bp, mp_size_t bn);

/* deprecated aliases */
#define flint_mpn_gcd_full flint_mpn_gcd
#define flint_mpn_gcd_full2(gp, ap, an, bp, bn, scr) flint_mpn_gcd(gp, ap, an, bp, bn)

/* the same with the interfaces of GMP's mpn_gcd and mpn_gcdext (ported
   from GMP, using FLINT's multiplication and division and fft_small
   transforms in the half-gcd matrix products): un >= vn > 0, the inputs
   are destroyed; see the documentation */
mp_size_t _flint_mpn_gcd_inplace(mp_ptr gp, mp_ptr up, mp_size_t un, mp_ptr vp, mp_size_t vn);
mp_size_t _flint_mpn_gcdext_inplace(mp_ptr gp, mp_ptr sp, mp_size_t * sn, mp_ptr up, mp_size_t un, mp_ptr vp, mp_size_t vn);

/* gcd of a vector (content): of the single limbs x[0], ..., x[len - 1] and
   g (zero allowed), respectively of the normalised values {xp[i], xn[i]}
   (xn[i] = 0 for zero) and {g, gn} (gn = 0 for none) */
ulong flint_mpn_gcd_vec_1(mp_srcptr x, slong len, ulong g);
mp_size_t flint_mpn_gcd_vec(mp_ptr g, mp_size_t gn, const mp_srcptr * xp, const mp_size_t * xn, slong len);

/* gcd of two odd two-limb values: GMP's (assembly) mpn_gcd_22 if available,
   which returns GMP's mp_double_limb_t, else a port of its C version */
#if FLINT_HAVE_NATIVE_mpn_gcd_22
typedef struct { mp_limb_t d0, d1; } flint_mpn_double_limb_t;
# define mpn_gcd_22 __gmpn_gcd_22
flint_mpn_double_limb_t mpn_gcd_22(mp_limb_t, mp_limb_t, mp_limb_t, mp_limb_t);
MPN_EXTRAS_INLINE void
_flint_mpn_gcd_22(mp_ptr g, mp_limb_t u1, mp_limb_t u0, mp_limb_t v1, mp_limb_t v0)
{
    flint_mpn_double_limb_t t = mpn_gcd_22(u1, u0, v1, v0);
    g[0] = t.d0;
    g[1] = t.d1;
}
#else
void _flint_mpn_gcd_22(mp_ptr g, mp_limb_t u1, mp_limb_t u0, mp_limb_t v1, mp_limb_t v0);
#endif

/* Half-gcd (HGCD) internals, following GMP's mpn_hgcd* functions. A matrix
   M = (p00, p01; p10, p11) with entries of n limbs (of allocation alloc),
   respectively a single-limb matrix (u00, u01; u10, u11). */
typedef struct
{
    mp_limb_t u[2][2];
}
flint_mpn_hgcd_matrix1_struct;

typedef struct
{
    mp_size_t alloc;
    mp_size_t n;
    mp_ptr p[2][2];
}
flint_mpn_hgcd_matrix_struct;

#define FLINT_MPN_HGCD_MATRIX_INIT_ITCH(n) (4 * (((n) + 1) / 2 + 1))
#define FLINT_MPN_GCDEXT_LEHMER_N_ITCH(n) (4 * (n) + 3)

typedef void _flint_mpn_gcd_subdiv_step_hook(void * ctx, mp_srcptr gp, mp_size_t gn, mp_srcptr qp, mp_size_t qn, int d);

typedef struct
{
    /* result parameters */
    mp_ptr gp;
    mp_size_t gn;
    mp_ptr up;
    mp_size_t * usize;
    /* cofactors updated in the hook */
    mp_size_t un;
    mp_ptr u0;
    mp_ptr u1;
    mp_ptr tp;
}
_flint_mpn_gcdext_ctx_struct;

int _flint_mpn_hgcd2(mp_limb_t ah, mp_limb_t al, mp_limb_t bh, mp_limb_t bl, flint_mpn_hgcd_matrix1_struct * M);
mp_size_t _flint_mpn_hgcd_mul_matrix1_vector(const flint_mpn_hgcd_matrix1_struct * M, mp_ptr rp, mp_srcptr ap, mp_ptr bp, mp_size_t n);
mp_size_t _flint_mpn_hgcd_mul_matrix1_inverse_vector(const flint_mpn_hgcd_matrix1_struct * M, mp_ptr rp, mp_srcptr ap, mp_ptr bp, mp_size_t n);

void _flint_mpn_hgcd_matrix_init(flint_mpn_hgcd_matrix_struct * M, mp_size_t n, mp_ptr p);
void _flint_mpn_hgcd_matrix_update_q(flint_mpn_hgcd_matrix_struct * M, mp_srcptr qp, mp_size_t qn, unsigned int col, mp_ptr tp);
void _flint_mpn_hgcd_matrix_mul_1(flint_mpn_hgcd_matrix_struct * M, const flint_mpn_hgcd_matrix1_struct * M1, mp_ptr tp);
void _flint_mpn_hgcd_matrix_mul(flint_mpn_hgcd_matrix_struct * M, const flint_mpn_hgcd_matrix_struct * M1, mp_ptr tp);
mp_size_t _flint_mpn_hgcd_matrix_adjust(const flint_mpn_hgcd_matrix_struct * M, mp_size_t n, mp_ptr ap, mp_ptr bp, mp_size_t p, mp_ptr tp);
mp_size_t _flint_mpn_hgcd_matrix22_mul_strassen_itch(mp_size_t rn, mp_size_t mn);
void _flint_mpn_hgcd_matrix22_mul_strassen(mp_ptr r0, mp_ptr r1, mp_ptr r2, mp_ptr r3, mp_size_t rn, mp_srcptr m0, mp_srcptr m1, mp_srcptr m2, mp_srcptr m3, mp_size_t mn, mp_ptr tp);

mp_size_t _flint_mpn_gcd_subdiv_step(mp_ptr ap, mp_ptr bp, mp_size_t n, mp_size_t s, _flint_mpn_gcd_subdiv_step_hook * hook, void * ctx, mp_ptr tp);
mp_size_t _flint_mpn_hgcd_step(mp_size_t n, mp_ptr ap, mp_ptr bp, mp_size_t s, flint_mpn_hgcd_matrix_struct * M, mp_ptr tp);
mp_size_t _flint_mpn_hgcd_itch(mp_size_t n);
mp_size_t _flint_mpn_hgcd(mp_ptr ap, mp_ptr bp, mp_size_t n, flint_mpn_hgcd_matrix_struct * M, mp_ptr tp);
mp_size_t _flint_mpn_hgcd_appr_itch(mp_size_t n);
int _flint_mpn_hgcd_appr(mp_ptr ap, mp_ptr bp, mp_size_t n, flint_mpn_hgcd_matrix_struct * M, mp_ptr tp);
mp_size_t _flint_mpn_hgcd_reduce_itch(mp_size_t n, mp_size_t p);
mp_size_t _flint_mpn_hgcd_reduce(flint_mpn_hgcd_matrix_struct * M, mp_ptr ap, mp_ptr bp, mp_size_t n, mp_size_t p, mp_ptr tp);

void _flint_mpn_gcdext_hook(void * p, mp_srcptr gp, mp_size_t gn, mp_srcptr qp, mp_size_t qn, int d);
mp_size_t _flint_mpn_gcdext_lehmer_n(mp_ptr gp, mp_ptr up, mp_size_t * usize, mp_ptr ap, mp_ptr bp, mp_size_t n, mp_ptr tp);

/* modular arithmetic ********************************************************/

void flint_mpn_mulmod_preinv1(mp_ptr r, mp_srcptr a, mp_srcptr b, mp_size_t n, mp_srcptr d, mp_limb_t dinv, ulong norm);
void flint_mpn_mulmod_preinvn(mp_ptr r, mp_srcptr a, mp_srcptr b, mp_size_t n, mp_srcptr d, mp_srcptr dinv, ulong norm);
void flint_mpn_powmod_preinvn(mp_ptr res, mp_srcptr a, mp_srcptr e, mp_size_t en, mp_size_t n, mp_srcptr d, mp_srcptr dinv, ulong norm);

#define MPN_MULMOD_PRECOND_NONE 0
#define MPN_MULMOD_PRECOND_SHOUP 1
#define MPN_MULMOD_PRECOND_MATRIX 2

int flint_mpn_mulmod_want_precond(mp_size_t n, slong num, ulong norm);

void flint_mpn_mulmod_precond_matrix_precompute(mp_ptr apre, mp_srcptr a, mp_size_t n, mp_srcptr d, mp_srcptr dinv, ulong norm);
mp_size_t flint_mpn_mulmod_precond_matrix_alloc(mp_size_t n);
void flint_mpn_mulmod_precond_matrix(mp_ptr rp, mp_srcptr apre, mp_srcptr b, mp_size_t n, mp_srcptr d, mp_srcptr dinv, ulong norm);

void flint_mpn_mulmod_precond_shoup_precompute(mp_ptr apre, mp_srcptr a, mp_size_t n, mp_srcptr dnormed, mp_srcptr dinv, ulong norm);
void flint_mpn_mulmod_precond_shoup(mp_ptr res, mp_srcptr a, mp_srcptr apre, mp_srcptr b, mp_size_t n, mp_srcptr d, ulong norm);

void flint_mpn_fmmamod_preinvn(mp_ptr r, mp_srcptr a, mp_srcptr b, mp_srcptr e, mp_srcptr f, mp_size_t n, mp_srcptr d, mp_srcptr dinv, ulong norm);
void flint_mpn_fmmamod_preinvn_2(mp_ptr r, mp_srcptr a, mp_srcptr b, mp_srcptr e, mp_srcptr f, mp_srcptr d, mp_srcptr dinv, ulong norm);
void flint_mpn_fmmamod_precond_matrix(mp_ptr rp, mp_srcptr apre1, mp_srcptr b1, mp_srcptr apre2, mp_srcptr b2, mp_size_t n, mp_srcptr d, mp_srcptr dinv, ulong norm);

int flint_mpn_mulmod_2expp1_basecase(mp_ptr xp, mp_srcptr yp, mp_srcptr zp, int c, flint_bitcnt_t b, mp_ptr tp);

/* square roots modulo an odd prime ******************************************/

int flint_mpn_is_square_mod(nn_srcptr a, nn_srcptr d, mp_size_t n);
int flint_mpn_sqrtmod(nn_ptr res, nn_srcptr a, nn_srcptr d, mp_size_t n);
int flint_mpn_sqrtmod_preinv(nn_ptr res, nn_srcptr a, nn_srcptr d, mp_size_t n, nn_srcptr dinv, flint_bitcnt_t norm);

/* miscellaneous *************************************************************/

double flint_mpn_get_d(mp_srcptr ptr, mp_size_t size, mp_size_t sign, long exp);

/* random ********************************************************************/

void flint_mpn_rrandom(mp_ptr rp, flint_rand_t state, mp_size_t n);
void flint_mpn_rrandomb(mp_ptr rp, flint_rand_t state, flint_bitcnt_t n);
void flint_mpn_urandomb(mp_ptr rp, flint_rand_t state, flint_bitcnt_t n);
void flint_mpn_urandomm(mp_ptr rp, flint_rand_t state, mp_srcptr xp, mp_size_t xn);

/******************************************************************************
    Divisions where the quotient is expected to be small. All function do:
        input: n > d > 0
        output: q = n/d, r = n%d
    for various small sizes of n and d.
    Not in a function because compiler refuses to inline eudiv_qrrnndd.
    Each macro takes a prefix t for its local vars.
******************************************************************************/

#define eudiv_qrnd(q, r, n, d, t)           \
do {                                        \
    mp_limb_t t##q, t##a = n, t##b = d;     \
                                            \
    FLINT_ASSERT(t##a > t##b);              \
    FLINT_ASSERT(t##b > 0);                 \
                                            \
    t##a -= t##b;                           \
    for (t##q = 1; t##q < 5; t##q++)        \
    {                                       \
        if (t##a < t##b)                    \
            goto t##quotient_found;         \
        t##a -= t##b;                       \
    }                                       \
    t##q += t##a / t##b;                    \
    t##a = t##a % t##b;                     \
                                            \
t##quotient_found:                          \
                                            \
    q = t##q;                               \
    r = t##a;                               \
} while (0)

#define eudiv_qqrnnd(q1, q0, r0, n1, n0, d0, t)         \
do {                                                    \
    mp_limb_t t##a1 = n1, t##a0 = n0, t##b0 = d0;       \
    mp_limb_t t##q1, t##q0, t##r0, t##u;                \
                                                        \
    FLINT_ASSERT(t##a1 > 0 || t##a0 > t##b0);           \
                                                        \
    udiv_qrnnd(t##q1, t##u, 0, t##a1, t##b0);           \
    udiv_qrnnd(t##q0, t##r0, t##u, t##a0, t##b0);       \
                                                        \
    q1 = t##q1;                                         \
    q0 = t##q0;                                         \
    r0 = t##r0;                                         \
} while (0)

/* d must be normalized, i.e. d1 != 0 */
#define eudiv_qrrnndd(q0, r1, r0, n1, n0, d1, d0, t)                        \
do {                                                                        \
    int t##i;                                                               \
    mp_limb_t t##a1 = n1, t##a0 = n0, t##b1 = d1, t##b0 = d0;               \
    mp_limb_t t##r1, t##r0, t##u2, t##u1, t##u0, t##q, t##v1, t##v0;        \
                                                                            \
    FLINT_ASSERT(t##a1 != 0);                                               \
    FLINT_ASSERT(t##b1 != 0);                                               \
    FLINT_ASSERT(t##b1 < t##a1 || (t##b1 == t##a1 && t##b0 < t##a0));       \
                                                                            \
    t##q = 1;                                                               \
                                                                            \
    sub_ddmmss(t##r1,t##r0, t##a1,t##a0, t##b1,t##b0);                      \
                                                                            \
t##subtract:                                                                \
                                                                            \
    for (t##i = 2; t##i <= 4; t##i++)                                       \
    {                                                                       \
        sub_dddmmmsss(t##u2,t##u1,t##u0, 0,t##r1,t##r0, 0,t##b1,t##b0);     \
        if (t##u2 != 0)                                                     \
            goto t##quotient_found;                                         \
        t##q += 1;                                                          \
        t##r0 = t##u0;                                                      \
        t##r1 = t##u1;                                                      \
    }                                                                       \
                                                                            \
    if (t##r1 != 0)                                                         \
    {                                                                       \
        int t##ncnt, t##dcnt;                                               \
        mp_limb_t t##qq = 0;                                                \
                                                                            \
        t##ncnt = flint_clz(t##r1);                                \
        t##dcnt = flint_clz(t##b1);                                \
        t##dcnt -= t##ncnt;                                                 \
        if (t##dcnt <= 0)                                                   \
            goto t##subtract;                                               \
                                                                            \
        t##v1 = (t##b1 << t##dcnt) | (t##b0 >> (FLINT_BITS - t##dcnt));     \
        t##v0 = t##b0 << t##dcnt;                                           \
                                                                            \
        do {                                                                \
            sub_dddmmmsss(t##u2,t##u1,t##u0, 0,t##r1,t##r0, 0,t##v1,t##v0); \
            t##qq = 2*t##qq + 1 + t##u2;                                    \
            t##r1 = t##u2 ? t##r1 : t##u1;                                  \
            t##r0 = t##u2 ? t##r0 : t##u0;                                  \
            t##v0 = (t##v1 << (FLINT_BITS - 1)) | (t##v0 >> 1);             \
            t##v1 = t##v1 >> 1;                                             \
            t##dcnt--;                                                      \
        } while (t##dcnt >= 0);                                             \
                                                                            \
        t##q += t##qq;                                                      \
    }                                                                       \
                                                                            \
t##quotient_found:                                                          \
                                                                            \
    FLINT_ASSERT(t##r1 < t##b1 || (t##r1 == t##b1 && t##r0 < t##b0));       \
                                                                            \
    q0 = t##q;                                                              \
    r0 = t##r0;                                                             \
    r1 = t##r1;                                                             \
} while (0)

/* Sizes in limbs from which the complex functions below use the
   transformed (fft_small) path (products and squares separately). See
   the comment in mpn_extras/mul_complex.c for measured defaults. */
FLINT_DLL extern slong flint_mpn_mul_complex_fft_cutoff;
FLINT_DLL extern slong flint_mpn_sqr_complex_fft_cutoff;

/* Size in limbs (of the shorter operand) from which the full, low and
   windowed products of a real or imaginary operand -- some part zero --
   use the transformed path, which transforms only the nonzero parts:
   an operand with a single nonzero part is transformed once for both
   output parts. The first serves the full and low products, the
   second the windows with lo > 0. */
FLINT_DLL extern slong flint_mpn_mul_complex_sparse_fft_cutoff;
FLINT_DLL extern slong flint_mpn_mulmid_complex_sparse_fft_cutoff;

/* Complex multiplication with separate sign bits (0 = nonnegative):
   zr + i zi = (ar + i ai) (br + i bi), outputs being exact magnitudes
   and signs.

   The full products take an independent length (>= 1 limb) for every
   part, which need not be normalized, and report a *signed length* for
   each output: the magnitude occupies |len| limbs and len < 0 means
   negative. Limbs above |len| are not significant, though the
   transformed path may zero them, so an fmpz caller can use the value
   as an mpz size directly. zr and zi must each have room for
   max(arn, ain) + max(brn, bin) + 1 limbs (2 max(arn, ain) + 1 for the
   square) -- one bound for both, covering either product plus the carry
   of the sum. The algorithm is chosen per shape: schoolbook when any
   part is much shorter than its partner, Karatsuba when the parts are
   internally balanced within each operand, and the transformed
   fft_small path when they are balanced and large. The two operands
   need not resemble each other in size.

   The high variants take a single length n for all four parts and
   receive exactly n + 1 limbs, zero padded, with a sign: they are the
   limbs [n, 2n] of the exact result. Relative to the exact value the
   error is below 2 + 3 (n + 4)/2^64 ulp of the lowest returned limb
   (below 2 + 2 (n + 4)/2^64 for the square) -- each underlying high
   product errs by (-1 - eps, +eps) ulp against the exact value, and
   each output combines at most three -- so below 3 ulp for any
   practical n; the transformed path stays within (-1.5, +0.5). */
void flint_mpn_mul_complex(nn_ptr zr, slong * zr_len, nn_ptr zi, slong * zi_len,
    nn_srcptr ar, mp_size_t arn, int ar_sgn,
    nn_srcptr ai, mp_size_t ain, int ai_sgn,
    nn_srcptr br, mp_size_t brn, int br_sgn,
    nn_srcptr bi, mp_size_t bin, int bi_sgn);
void flint_mpn_sqr_complex(nn_ptr zr, slong * zr_len, nn_ptr zi, slong * zi_len,
    nn_srcptr ar, mp_size_t arn, int ar_sgn,
    nn_srcptr ai, mp_size_t ain, int ai_sgn);

/* the individual algorithms behind the two functions above, exposed for
   comparison and tuning: classical (schoolbook), Karatsuba (three
   products for a multiplication, one for the real part of a square) and
   the transformed fft_small path, which returns 0 without touching the
   outputs when it is unavailable or the plan is inadmissible. All accept
   any shape; the dispatchers choose between them by shape and size. */
void flint_mpn_mul_complex_classical(nn_ptr zr, slong * zr_len,
    nn_ptr zi, slong * zi_len,
    nn_srcptr ar, mp_size_t arn, int ar_sgn,
    nn_srcptr ai, mp_size_t ain, int ai_sgn,
    nn_srcptr br, mp_size_t brn, int br_sgn,
    nn_srcptr bi, mp_size_t bin, int bi_sgn);
void flint_mpn_mul_complex_karatsuba(nn_ptr zr, slong * zr_len,
    nn_ptr zi, slong * zi_len,
    nn_srcptr ar, mp_size_t arn, int ar_sgn,
    nn_srcptr ai, mp_size_t ain, int ai_sgn,
    nn_srcptr br, mp_size_t brn, int br_sgn,
    nn_srcptr bi, mp_size_t bin, int bi_sgn);
int flint_mpn_mul_complex_fft_small(nn_ptr zr, slong * zr_len,
    nn_ptr zi, slong * zi_len,
    nn_srcptr ar, mp_size_t arn, int ar_sgn,
    nn_srcptr ai, mp_size_t ain, int ai_sgn,
    nn_srcptr br, mp_size_t brn, int br_sgn,
    nn_srcptr bi, mp_size_t bin, int bi_sgn);
void flint_mpn_sqr_complex_classical(nn_ptr zr, slong * zr_len,
    nn_ptr zi, slong * zi_len,
    nn_srcptr ar, mp_size_t arn, int ar_sgn,
    nn_srcptr ai, mp_size_t ain, int ai_sgn);
void flint_mpn_sqr_complex_karatsuba(nn_ptr zr, slong * zr_len,
    nn_ptr zi, slong * zi_len,
    nn_srcptr ar, mp_size_t arn, int ar_sgn,
    nn_srcptr ai, mp_size_t ain, int ai_sgn);
int flint_mpn_sqr_complex_fft_small(nn_ptr zr, slong * zr_len,
    nn_ptr zi, slong * zi_len,
    nn_srcptr ar, mp_size_t arn, int ar_sgn,
    nn_srcptr ai, mp_size_t ain, int ai_sgn);
/* Low products: zr and zi receive the real and imaginary parts of the
   product mod B^n, as n-limb two's-complement residues (no sign). The
   inputs are as for the full products (magnitudes of any lengths >= 1
   limb with sign bits); only their low n limbs are read. zr and zi must
   not overlap each other or the inputs. */
FLINT_DLL extern slong flint_mpn_mullow_complex_fft_cutoff;
FLINT_DLL extern slong flint_mpn_sqrlow_complex_fft_cutoff;

void flint_mpn_mullow_complex(nn_ptr zr, nn_ptr zi, mp_size_t n,
    nn_srcptr ar, mp_size_t arn, int ar_sgn,
    nn_srcptr ai, mp_size_t ain, int ai_sgn,
    nn_srcptr br, mp_size_t brn, int br_sgn,
    nn_srcptr bi, mp_size_t bin, int bi_sgn);
void flint_mpn_sqrlow_complex(nn_ptr zr, nn_ptr zi, mp_size_t n,
    nn_srcptr ar, mp_size_t arn, int ar_sgn,
    nn_srcptr ai, mp_size_t ain, int ai_sgn);
void flint_mpn_mullow_complex_classical(nn_ptr zr, nn_ptr zi, mp_size_t n,
    nn_srcptr ar, mp_size_t arn, int ar_sgn,
    nn_srcptr ai, mp_size_t ain, int ai_sgn,
    nn_srcptr br, mp_size_t brn, int br_sgn,
    nn_srcptr bi, mp_size_t bin, int bi_sgn);
void flint_mpn_mullow_complex_karatsuba(nn_ptr zr, nn_ptr zi, mp_size_t n,
    nn_srcptr ar, mp_size_t arn, int ar_sgn,
    nn_srcptr ai, mp_size_t ain, int ai_sgn,
    nn_srcptr br, mp_size_t brn, int br_sgn,
    nn_srcptr bi, mp_size_t bin, int bi_sgn);
int flint_mpn_mullow_complex_fft_small(nn_ptr zr, nn_ptr zi, mp_size_t n,
    nn_srcptr ar, mp_size_t arn, int ar_sgn,
    nn_srcptr ai, mp_size_t ain, int ai_sgn,
    nn_srcptr br, mp_size_t brn, int br_sgn,
    nn_srcptr bi, mp_size_t bin, int bi_sgn);
void flint_mpn_sqrlow_complex_classical(nn_ptr zr, nn_ptr zi, mp_size_t n,
    nn_srcptr ar, mp_size_t arn, int ar_sgn,
    nn_srcptr ai, mp_size_t ain, int ai_sgn);
void flint_mpn_sqrlow_complex_karatsuba(nn_ptr zr, nn_ptr zi, mp_size_t n,
    nn_srcptr ar, mp_size_t arn, int ar_sgn,
    nn_srcptr ai, mp_size_t ain, int ai_sgn);
int flint_mpn_sqrlow_complex_fft_small(nn_ptr zr, nn_ptr zi, mp_size_t n,
    nn_srcptr ar, mp_size_t arn, int ar_sgn,
    nn_srcptr ai, mp_size_t ain, int ai_sgn);

/* Windowed products: limbs [lo, hi) of the real and imaginary parts as
   two's-complement windows (hi - lo limbs each), equal to
   floor(x / B^lo) + e mod B^(hi - lo) for each exact part x with e = 0
   for lo = 0, |e| <= 1 on the transformed path and
   |e| < 4 (m + 1) 2^FLINT_BITS otherwise, m = min(max(arn, ain),
   max(brn, bin)). Inputs as for the low products. */
FLINT_DLL extern slong flint_mpn_mulmid_complex_fft_cutoff;
FLINT_DLL extern slong flint_mpn_sqrmid_complex_fft_cutoff;

void flint_mpn_mulmid_complex(nn_ptr zr, nn_ptr zi, mp_size_t lo, mp_size_t hi,
    nn_srcptr ar, mp_size_t arn, int ar_sgn,
    nn_srcptr ai, mp_size_t ain, int ai_sgn,
    nn_srcptr br, mp_size_t brn, int br_sgn,
    nn_srcptr bi, mp_size_t bin, int bi_sgn);
void flint_mpn_sqrmid_complex(nn_ptr zr, nn_ptr zi, mp_size_t lo, mp_size_t hi,
    nn_srcptr ar, mp_size_t arn, int ar_sgn,
    nn_srcptr ai, mp_size_t ain, int ai_sgn);
void flint_mpn_mulmid_complex_classical(nn_ptr zr, nn_ptr zi, mp_size_t lo, mp_size_t hi,
    nn_srcptr ar, mp_size_t arn, int ar_sgn,
    nn_srcptr ai, mp_size_t ain, int ai_sgn,
    nn_srcptr br, mp_size_t brn, int br_sgn,
    nn_srcptr bi, mp_size_t bin, int bi_sgn);
void flint_mpn_mulmid_complex_karatsuba(nn_ptr zr, nn_ptr zi, mp_size_t lo, mp_size_t hi,
    nn_srcptr ar, mp_size_t arn, int ar_sgn,
    nn_srcptr ai, mp_size_t ain, int ai_sgn,
    nn_srcptr br, mp_size_t brn, int br_sgn,
    nn_srcptr bi, mp_size_t bin, int bi_sgn);
int flint_mpn_mulmid_complex_fft_small(nn_ptr zr, nn_ptr zi, mp_size_t lo, mp_size_t hi,
    nn_srcptr ar, mp_size_t arn, int ar_sgn,
    nn_srcptr ai, mp_size_t ain, int ai_sgn,
    nn_srcptr br, mp_size_t brn, int br_sgn,
    nn_srcptr bi, mp_size_t bin, int bi_sgn);
void flint_mpn_sqrmid_complex_classical(nn_ptr zr, nn_ptr zi, mp_size_t lo, mp_size_t hi,
    nn_srcptr ar, mp_size_t arn, int ar_sgn,
    nn_srcptr ai, mp_size_t ain, int ai_sgn);
void flint_mpn_sqrmid_complex_karatsuba(nn_ptr zr, nn_ptr zi, mp_size_t lo, mp_size_t hi,
    nn_srcptr ar, mp_size_t arn, int ar_sgn,
    nn_srcptr ai, mp_size_t ain, int ai_sgn);
int flint_mpn_sqrmid_complex_fft_small(nn_ptr zr, nn_ptr zi, mp_size_t lo, mp_size_t hi,
    nn_srcptr ar, mp_size_t arn, int ar_sgn,
    nn_srcptr ai, mp_size_t ain, int ai_sgn);

void flint_mpn_mulhigh_n_complex(nn_ptr zr, int * zr_sgn, nn_ptr zi,
    int * zi_sgn, nn_srcptr ar, int ar_sgn, nn_srcptr ai, int ai_sgn,
    nn_srcptr br, int br_sgn, nn_srcptr bi, int bi_sgn, mp_size_t n);
void flint_mpn_sqrhigh_n_complex(nn_ptr zr, int * zr_sgn, nn_ptr zi,
    int * zi_sgn, nn_srcptr ar, int ar_sgn, nn_srcptr ai, int ai_sgn,
    mp_size_t n);

/* multi mod / multi CRT ******************************************************/

#include "nmod_types.h"

/*
    Precomputed data for simultaneous reduction of a multiprecision
    integer modulo a fixed list of single-limb moduli ("multi mod") and
    for the inverse operation ("multi CRT").

    Terminology
    -----------

    prime   one of the user-supplied single-limb moduli m_0, ..., m_{n-1}
            (pairwise coprime, not necessarily prime).

    leaf    a product l_j of one or more consecutive primes fitting in a
            single limb. Tiny primes are batched: e.g. 32-bit primes are
            grouped in pairs and 20-bit primes in triples. All work above the
            leaf level is done modulo the leaf products, and single-limb code
            splits/combines the individual primes below.

    chunk   a group of consecutive leaves whose product M_i has at most
            crt_chunk_limbs limbs. Chunks are the leaves of the subproduct
            tree. Within a chunk, CRT is done with a linear (basecase)
            algorithm: mpn_addmul_1 of precomputed multipliers.

    level   level 0 of the tree consists of the chunk products, level k
            consists of products of pairs of consecutive level k-1 nodes.
            The top level consists of a single node, the product P of all
            primes.

    All nodes at level k are stored contiguously in a packed array
    with a fixed slot size level_limbs[k] (the size of the largest node).

    Modular reduction descends the tree from the top down to level
    mod_base_level (>= 0), and then reduces each level-mod_base_level node
    residue directly modulo all leaves below it using a dot product with
    precomputed powers 2^(FLINT_BITS k) mod l_j. This is the mod basecase.

    CRT ascends from the level-0 chunks. The chunk values are computed as
    y_i = sum_j ((r_j c_{ij}) mod l_j) (M_i / l_j) where the precomputed
    c_{ij} include the inverse cofactors (M_i/l_j)^-1 mod l_j and the
    fractional cofactor w_i of the chunk in the tree, so that
    y_i = x w_i mod M_i (unreduced, y_i < b_i M_i where b_i is the number of
    leaves in the chunk). Nodes are combined as A = B*v_c + C*v_b without
    any intermediate reductions (the values grow by at most one bit per
    level); a single reduction modulo P is done at the end.
*/

typedef struct
{
    nmod_t mod;
    ulong r64;      /* 2^64 mod n */
    ulong r128;     /* 2^128 mod n */
    ulong qhi;      /* floor(2^128 / n), used for n < 2^63 */
    ulong qlo;
    ulong npre;     /* Barrett precomputation for n */
}
flint_mpn_crt_leaf_struct;

typedef struct flint_mpn_crt_struct
{
    slong num_primes;
    nn_ptr primes;
    nmod_t * prime_mod;         /* per prime */

    /* leaves */
    slong num_leaves;
    slong * leaf_start;         /* index of first prime of leaf, length num_leaves + 1 */
    flint_mpn_crt_leaf_struct * leaf;   /* leaf moduli with reduction data */
    nn_ptr prime_barrett;       /* Barrett precomputation for each prime */
    int all_single;             /* all leaves consist of a single prime */

    /* chunks (CRT basecase) */
    slong num_chunks;
    slong * chunk_start;        /* index of first leaf of chunk, length num_chunks + 1 */
    slong crt_chunk_limbs;      /* max limb size of chunk products (= level_limbs[0]) */
    nn_ptr crt_mult;            /* (all_single only) per prime: crt_chunk_limbs limbs,
                                   (M_i/p_t) ((M_i/p_t)^-1 mod p_t) w_i mod M_i, zero padded */
    nn_ptr crt_leaf_mult;       /* (batched leaves or fixed-length path) per leaf:
                                   crt_chunk_limbs limbs, M_i / l_j, zero padded */
    nn_ptr prime_crt_coeff;     /* per prime: coefficient for combining the residues of
                                   a leaf into u_j = x (M_i/l_j)^-1 w_i mod l_j */
    nn_ptr prime_crt_shoup;     /* per prime: Shoup precomputation for prime_crt_coeff
                                   (fixed-length path with single-prime leaves only) */
    int crt_use_shoup;

    /* fixed-length CRT (single chunk, small product) */
    int crt_fixed;              /* whether the fixed-length path applies */
    int crt_fixed_m;            /* number of limbs of the fixed-length cofactors */

    /* small-value shortcut: CRT structure for the first few primes, used
       to detect and verify reconstructions that are much smaller than P */
    struct flint_mpn_crt_struct * crt_small;

    /* subproduct tree */
    slong num_levels;
    slong * level_count;        /* number of nodes per level */
    slong * level_limbs;        /* slot size per level */
    nn_ptr * level_prod;        /* packed node products */
    slong ** level_len;         /* actual limb counts of node products */

    /* division data for modular reduction of parent residue to child */
    int * level_use_preinv;     /* whether to use a precomputed inverse when
                                   reducing to this level */
    nn_ptr * level_prod_norm;   /* normalised (shifted) node products */
    nn_ptr * level_inv;         /* precomputed inverses */
    ulong ** level_norm;        /* shift counts */

    /* mod basecase */
    slong mod_base_level;       /* level at which to switch to the basecase */
    slong mod_base_limbs;       /* limb size of the mod basecase slots (= level_limbs[mod_base_level]) */
    slong mod_pow_limbs;        /* length of the power tables (>= mod_base_limbs; larger when
                                   the basecase is at the top level so that inputs
                                   somewhat larger than P can be reduced directly) */
    nn_ptr mod_pow;             /* per leaf: mod_pow_limbs limbs, 2^(64k) mod l_j */
    int mod_pow_slack;          /* whether mod_base_limbs * l_j < 2^64 for all leaves (2-limb accumulator suffices) */

    /* misc */
    int flags;                  /* which operations are supported */
    nn_ptr prod;                /* product of all primes (points into top level) */
    slong prod_len;
    nn_ptr prod_half;           /* floor(P/2) for symmetric representation */

    slong work_level_limbs;     /* size of one ping-pong level buffer */
    slong work_max_count;       /* max number of nodes on a level */
    slong tmp_limbs;            /* workspace required by multi_mod / multi_crt */
}
flint_mpn_crt_struct;

typedef flint_mpn_crt_struct flint_mpn_crt_t[1];

/* flags selecting which operations to precompute for */
#define FLINT_MPN_CRT_MOD 1
#define FLINT_MPN_CRT_CRT 2

void flint_mpn_crt_init(flint_mpn_crt_t C, nn_srcptr primes, slong num_primes);
void flint_mpn_crt_init2(flint_mpn_crt_t C, nn_srcptr primes, slong num_primes, int flags);
void flint_mpn_crt_clear(flint_mpn_crt_t C);

void flint_mpn_crt_init_tuned(flint_mpn_crt_t C, nn_srcptr primes, slong num_primes,
        int flags, slong crt_chunk_bits, slong mod_base_bits, slong preinv_cutoff);

void flint_mpn_multi_mod(nn_ptr out, nn_srcptr x, slong xn, const flint_mpn_crt_t C, nn_ptr tmp);

int flint_mpn_multi_crt(nn_ptr out, nn_srcptr res, const flint_mpn_crt_t C, int sign, nn_ptr tmp);

ulong flint_mpn_crt_mod_leaf(nn_srcptr a, slong an, const flint_mpn_crt_t C, slong j);

void flint_mpn_multi_mod_vec(nn_ptr out, slong out_stride, nn_srcptr x, slong xn, slong len, const flint_mpn_crt_t C, nn_ptr tmp);
void flint_mpn_multi_crt_vec(nn_ptr out, slong out_stride, int * negative, nn_srcptr res, slong res_stride, slong len, const flint_mpn_crt_t C, int sign, nn_ptr tmp);

void flint_mpn_multi_mod_once(nn_ptr out, nn_srcptr x, slong xn, nn_srcptr primes, slong num_primes);
int flint_mpn_multi_crt_once(nn_ptr out, slong * outn, nn_ptr prod, nn_srcptr res, nn_srcptr primes, slong num_primes, int sign);

#ifdef __cplusplus
}
#endif

#endif
