/*
    Copyright (C) 2024 Albin Ahlbäck

    This file is part of FLINT.

    FLINT is free software: you can redistribute it and/or modify it under
    the terms of the GNU Lesser General Public License (LGPL) as published
    by the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.  See <https://www.gnu.org/licenses/>.
*/

/* Tuning for generic CPU. Is probably far from optimal. */

#ifndef FLINT_MPARAM_H
#define FLINT_MPARAM_H

#define FLINT_FFT_SMALL_MUL_THRESHOLD           1000
#define FLINT_FFT_SMALL_SQR_THRESHOLD           1400

#define FLINT_FFT_MUL_THRESHOLD                32000
#define FLINT_FFT_SQR_THRESHOLD                32000

#define FFT_TAB \
   { {4, 4}, {4, 3}, {3, 2}, {2, 1}, {2, 1} }

#define MULMOD_TAB \
   { 4, 4, 4, 4, 4, 3, 3, 3, 3, 3, 3, 3, 2, 2, 2, 2, 2, 1, 1 }

#define FFT_N_NUM                                 19
#define FFT_MULMOD_2EXPP1_CUTOFF                 128

#define FLINT_PREINVERT_LIMB_USE_NATIVE 0

/* fft_small: round quotients with the hardware round instruction (1),
   or with the magic constant fmadd(x, y, 1.5*2^52) - 1.5*2^52 (0), which
   is faster where vroundpd is 2 uops with 8 cycle latency (Intel since
   Skylake) but slower on Zen 2-5 where it is 1 uop with 3 cycle latency */
#define FLINT_FFT_SMALL_ROUND_USE_NATIVE 1

#define FLINT_MULMOD_SHOUP_THRESHOLD 10

/* Shoup precomputation floor(a 2^FLINT_BITS / n) without a hardware division
   (multiplications by the precomputed inverse of n): the division is slow
   here (or done in software). FLINT_MULMOD_SHOUP_THRESHOLD above is the
   crossover for this precomputation. */
#define FLINT_MULMOD_SHOUP_PRECOMP_PREINV 1

#define FLINT_MPN_MULHIGH_FFT_SMALL_CUTOFF 500

#define FLINT_MPN_SQRHIGH_FFT_SMALL_CUTOFF 580

/* Newton division, Newton Hensel (exact) division and Newton square root
   replace the divide and conquer code from these limb counts (divisor /
   quotient limbs for the first two, divisor limbs for the next two with
   a quotient at least as long, respectively at least four times as long,
   input limbs for the square root). Not tuned on this target: Skylake values
   from src/mpn_extras/tune/tune-div.c, except for
   FLINT_MPN_DIVEXACT_NEWTON_CUTOFF (measured against GMP's mpn_divexact
   before FLINT had its own schoolbook and divide and conquer Hensel
   division). */
#define FLINT_MPN_TDIV_QR_NEWTON_CUTOFF 950
#define FLINT_MPN_TDIV_QR_NEWTON_LONG_CUTOFF 608
#define FLINT_MPN_DIVEXACT_NEWTON_CUTOFF 700
#define FLINT_MPN_DIVEXACT_UNBALANCED_CUTOFF 531
#define FLINT_MPN_SQRTREM_NEWTON_CUTOFF 7423

/* division cutoffs (Skylake values, not tuned on this target) */
#define FLINT_MPN_DIV_DC_CUTOFF 18
#define FLINT_MPN_DIVAPPR_DC_CUTOFF 32
#define FLINT_MPN_DIVAPPROX_SHORT_CUTOFF 45
#define FLINT_MPN_TDIV_Q_DC_CUTOFF 72
#define FLINT_MPN_DIVAPPROX_NEWTON_CUTOFF 921
#define FLINT_MPN_INV_NEWTON_CUTOFF 37
#define FLINT_MPN_INV_NEWTON_LONG_CUTOFF 24
#define FLINT_MPN_INV_NEWTON_VERYLONG_CUTOFF 171
#define FLINT_MPN_DC_BDIV_QR_CUTOFF 40
#define FLINT_MPN_DC_BDIV_Q_CUTOFF 80

/* one-limb division by a chain of hardware divisions below these dividend
   lengths (unnormalized / normalized divisor); only used with
   FLINT_PREINVERT_LIMB_USE_NATIVE (Zen 3 values) */
#define FLINT_MPN_DIVREM_1_HW_CUTOFF 24
#define FLINT_MPN_DIVREM_1_NORM_HW_CUTOFF 14

/* two-limb divisors by hardware 2/1 divisions without an inverse below this
   dividend length; only used with FLINT_PREINVERT_LIMB_USE_NATIVE (Zen 3
   value) */
#define FLINT_MPN_DIV_2_HW_CUTOFF 22

/* 3- to 7-limb divisors by hardware 2/1 divisions without an inverse for
   quotients shorter than this */
#define FLINT_MPN_DIV_SMALL_HW_QN_CUTOFF 4

/* two-limb divisors by GMP's assembly mpn_divrem_2 (when available) from
   this dividend length (1000000: never) */
#define FLINT_MPN_DIV_2_GMP_CUTOFF 3


/*
    nmod_mat_mul: dispatch of the SIMD kernels nmod_mat_mul_u32 (moduli
    below 2^32), nmod_mat_mul_u52 (AVX512-IFMA, moduli up to 2^52) and,
    without IFMA, nmod_mat_mul_k52 / nmod_mat_mul_fp50 (moduli up to 2^52
    / below 2^50); see src/nmod_mat/mul.c and the profile p-mul_tune.c
    (not measured on this target: defaults).
      SIMD_MIN_DIM         use the SIMD kernels when B has at least this
                           many columns and A this many rows (or half as
                           many if B has 4x as many columns), for any inner
                           dimension
      SIMD_STRASSEN_CUTOFF single-threaded, Strassen is put on top of the
                           SIMD kernels from this dimension on (0: never;
                           values 1 to 4 also mean never)
      BLAS_1PASS_CUTOFF    when one dgemm pass suffices (k*(n/2)^2 < 2^53),
                           nmod_mat_mul_blas is preferred to u32 from this
                           dimension on and, with an external BLAS, also to
                           the single-IFMA mode of u52 (0: never)
      BLAS_1PASS_CUTOFF_MT the same with 3 threads or more (measured with
                           4; with 2 threads: the geometric mean)
      U52_MIN_BITS         u52 is preferred to u32 from this modulus bit
                           size on (through 52 bits)
      U52_LO_MAX_BITS      u52 in its single-IFMA mode is preferred to u32
                           up to this modulus bit size (0: never)
      K52_MIN_BITS         without IFMA, from this modulus bit size on
                           (through 52 bits) the two-limb integer kernel
                           nmod_mat_mul_k52 replaces blas + CRT (0: never)
      FP50_MAX_BITS        in that range, the floating point kernel
                           nmod_mat_mul_fp50 is preferred to k52 up to
                           this modulus bit size (through 50; 0: never)
      K52_BLAS_CUTOFF      in that range and with an external BLAS,
                           nmod_mat_mul_blas and its CRT are preferred to
                           k52 / fp50 from this dimension on (0: never).
                           The crossover grows with the modulus size, since
                           blas needs more primes; the value is the one for
                           the bottom of the range.
*/
#define FLINT_NMOD_MAT_MUL_SIMD_MIN_DIM 8
#define FLINT_NMOD_MAT_MUL_BLAS_1PASS_CUTOFF 256
#define FLINT_NMOD_MAT_MUL_BLAS_1PASS_CUTOFF_MT 256
#define FLINT_NMOD_MAT_MUL_SIMD_STRASSEN_CUTOFF 768
#define FLINT_NMOD_MAT_MUL_U52_MIN_BITS 31
#define FLINT_NMOD_MAT_MUL_U52_LO_MAX_BITS 0
#define FLINT_NMOD_MAT_MUL_K52_MIN_BITS 33
#define FLINT_NMOD_MAT_MUL_FP50_MAX_BITS 50
#define FLINT_NMOD_MAT_MUL_K52_BLAS_CUTOFF 0

/*
    nmod_mat_mul: inner dimension from which u52 is preferred to fp50
    (33-50 bits) and, in its single-IFMA mode, to u32 (only used with
    AVX512-IFMA); see src/nmod_mat/mul.c (not measured on this target:
    default)
*/
#define FLINT_NMOD_MAT_MUL_U52_MIN_K 12

/*
    nmod_mat_mul: for moduli up to 2^32, fp50 is preferred to u32 for these
    inner dimensions (MIN_K > MAX_K: never); see src/nmod_mat/impl.h (not
    measured on this target: default, k = 1..3 on AVX2, k = 1
    otherwise)
*/
#if defined(__AVX2__) && !defined(__AVX512F__)
# define FLINT_NMOD_MAT_MUL_FP50_U32_MIN_K 1
# define FLINT_NMOD_MAT_MUL_FP50_U32_MAX_K 3
#else
# define FLINT_NMOD_MAT_MUL_FP50_U32_MIN_K 1
# define FLINT_NMOD_MAT_MUL_FP50_U32_MAX_K 1
#endif

/*
    nmod_vec_dot: the split-limbs SIMD dot product (AVX2 / AVX-512, moduli
    above 2^32) is used from this length on (0: never); see src/nmod_vec.h
    (not measured on this target: default)
*/
#define FLINT_NMOD_VEC_DOT_SPLIT_LIMBS_MIN_LEN 96

/*
    nmod_vec_dot: split limbs are used for moduli up to 2^this; see
    src/nmod_vec.h (not measured on this target: default, 60 with
    AVX512-IFMA, where u64 takes over, 64 otherwise)
*/
#if defined(__AVX512IFMA__)
# define FLINT_NMOD_VEC_DOT_SPLIT_LIMBS_MAX_BITS 60
#else
# define FLINT_NMOD_VEC_DOT_SPLIT_LIMBS_MAX_BITS 64
#endif

/*
    nmod_vec_dot: with AVX512-IFMA, the u52 SIMD dot product (moduli above
    2^32 up to 2^52) is used from this length on; see src/nmod_vec.h (not
    measured on this target: default)
*/
#define FLINT_NMOD_VEC_DOT_U52_MIN_LEN 40

/*
    radix_mulmid: with fft_small, the classical algorithm is used below this
    many limb products per limb of the convolution that fft_small computes;
    see src/radix.h (not measured on this target: default, between the
    measured 50 (Zen 4) and 80 (Cascade Lake))
*/
#define FLINT_RADIX_MULMID_FFT_SMALL_CUTOFF_RATIO 60

#endif
